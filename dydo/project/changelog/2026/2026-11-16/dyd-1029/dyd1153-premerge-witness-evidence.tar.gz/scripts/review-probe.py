from pathlib import Path
import subprocess, json, os, shutil, hashlib

root = Path.cwd()
out = Path('/tmp/dyd1153-merge-evidence')
events = []

def run(args, cwd=root, data=None, expected=0):
    env = {k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')}
    env.update(GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
    p = subprocess.run(args,cwd=cwd,input=data,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    events.append(dict(argv=list(map(str,args)),cwd=str(cwd),exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if expected is not None and p.returncode != expected:
        raise AssertionError(events[-1])
    return p

def git(cwd,*args,data=None,expected=0):
    return run(['git',*args],cwd,data,expected).stdout.strip()

try:
    assert git(root,'merge-base','--is-ancestor','f67a33df8990a8207e913e72972e58691898a60c','HEAD') == ''
    changed=run(['git','ls-files'],root).stdout.splitlines()
    sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in changed}
    dll = out/'artifacts/bin/DynaDocs/debug/dydo.dll'
    assert dll.is_file()
    fixture=out/'resolve-undo-fixture'
    main=fixture/'main'; tree=fixture/'tree'
    main.mkdir(parents=True)
    git(main,'init','-b','main')
    git(main,'config','user.name','Review'); git(main,'config','user.email','review@example.invalid')
    git(main,'config','commit.gpgsign','false')
    (main/'file.txt').write_text('base\n')
    git(main,'add','.'); git(main,'commit','-m','base')
    (main/'dydo.json').write_text('{"archive":{"reserveBytes":0,"reservePercent":0}}')
    git(main,'worktree','add','-b','topic',str(tree))
    oids=[git(tree,'hash-object','-w','--stdin',data=value+'\n') for value in ['unique ancestor','unique ours','unique theirs']]
    info='0 '+'0'*40+'\tfile.txt\n'+''.join('100644 '+oid+' '+str(stage)+'\tfile.txt\n' for stage,oid in enumerate(oids,1))
    git(tree,'update-index','--index-info',data=info)
    (tree/'file.txt').write_text('resolved working version\n')
    git(tree,'add','file.txt')
    before=git(tree,'ls-files','--resolve-undo')
    assert all(oid in before for oid in oids),before
    archive=run(['dotnet',str(dll),'archive','worktree',str(tree)],main,expected=None)
    result={'head':git(root,'rev-parse','HEAD'),'sourceHashes':sources,'dllSha256':hashlib.sha256(dll.read_bytes()).hexdigest(),
            'resolveUndoBefore':before,'oids':oids,'archiveExit':archive.returncode,'archiveOutput':archive.stdout}
    if archive.returncode==0:
        entry=next(p for p in (main/'.git/dydo/safe-delete-archive').iterdir() if p.is_dir() and not p.name.startswith('.'))
        git(main,'reflog','expire','--expire=now','--all'); git(main,'gc','--prune=now')
        result['sourceObjectsMissingAfterGc']=[run(['git','cat-file','-e',oid],main,expected=None).returncode!=0 for oid in oids]
        restore=run(['dotnet',str(dll),'archive','restore',entry.name],main,expected=None)
        result.update(restoreExit=restore.returncode,restoreOutput=restore.stdout)
        if restore.returncode==0:
            result['resolveUndoAfter']=git(tree,'ls-files','--resolve-undo')
            result['undoObjectPresent']=[run(['git','cat-file','-e',oid],tree,expected=None).returncode==0 for oid in oids]
            result['undoObjectBytes']=[git(tree,'cat-file','blob',oid,expected=None) for oid in oids]
            undo=run(['git','checkout','-m','--','file.txt'],tree,expected=None)
            result.update(undoExit=undo.returncode,undoStderr=undo.stderr,unmergedAfterUndo=git(tree,'ls-files','--unmerged',expected=None))
    (out/'resolve-undo-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
finally:
    (out/'probe-events.json').write_text(json.dumps(events,indent=2)+'\n')
    if (out/'resolve-undo-fixture').exists(): shutil.rmtree(out/'resolve-undo-fixture')
