from pathlib import Path
import subprocess,json,os,shutil,sys,hashlib

label, dll_arg, expected = sys.argv[1:]
root=Path.cwd(); out=Path('/tmp/dyd1029-bare-fix-proof')/label
out.mkdir(parents=True,exist_ok=False)
fixture=out/'fixture'; main=fixture/'main'; tree=fixture/'tree'; bare=tree/'nested.git'
dll=(root/dll_arg).resolve(); events=[]; result={}; real_git=shutil.which('git')
env={k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')}
env.update(GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
shim=out/'shim';shim.mkdir(); calls=out/'git-subprocesses.jsonl'
(shim/'git').write_text('#!'+sys.executable+'\nimport os,sys,json\nfrom pathlib import Path\nwith Path('+repr(str(calls))+').open("a") as f: f.write(json.dumps({"argv":sys.argv[1:],"cwd":os.getcwd()})+"\\n")\nos.execv('+repr(real_git)+', ['+repr(real_git)+', *sys.argv[1:]])\n')
(shim/'git').chmod(0o755)
env['PATH']=str(shim)+os.pathsep+env['PATH']
def run(argv,cwd=main,expected=0):
    p=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,text=True,capture_output=True)
    events.append({'argv':list(map(str,argv)),'cwd':str(cwd),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    if expected is not None: assert p.returncode==expected,events[-1]
    return p
def git(*args,cwd=main,expected=0): return run(['git',*args],cwd,expected).stdout.strip()
def snapshot(path):
    return {str(p.relative_to(path)): {'kind':'link','target':os.readlink(p)} if p.is_symlink() else {'kind':'directory','mode':p.stat().st_mode} if p.is_dir() else {'kind':'file','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':p.stat().st_mode} for p in sorted(path.rglob('*'))}
try:
    main.mkdir(parents=True)
    git('init','-b','main'); git('config','user.name','Fix witness'); git('config','user.email','fix@example.invalid'); git('config','commit.gpgsign','false')
    git('config','gc.auto','0'); git('config','maintenance.auto','false')
    (main/'file.txt').write_text('base\n');git('add','.');git('commit','-m','base')
    git('switch','-c','nested-unique');(main/'nested.txt').write_text('ordinary shared clone unique work\n');git('add','nested.txt');git('commit','-m','unique nested work')
    unique=git('rev-parse','HEAD');git('switch','main')
    (main/'dydo.json').write_text('{"archive":{"reserveBytes":0,"reservePercent":0}}')
    git('worktree','add','-b','topic',tree);git('clone','--bare','--shared',main,bare)
    git('branch','-D','nested-unique');git('reflog','expire','--expire=now','--all')
    assert git('rev-parse','--is-bare-repository',cwd=bare)=='true'
    assert git('show','nested-unique:nested.txt',cwd=bare)=='ordinary shared clone unique work'
    assert not list((bare/'objects').glob('??/*')) and not list((bare/'objects/pack').iterdir())
    before=snapshot(tree); branches=git('show-ref');trees=git('worktree','list','--porcelain');nested_refs=git('show-ref',cwd=bare)
    call_start=len(calls.read_text().splitlines())
    archived=run(['dotnet',dll,'archive','worktree',tree],expected=None)
    archive_calls=[json.loads(line) for line in calls.read_text().splitlines()[call_start:]]
    result={'head':git('rev-parse','HEAD',cwd=root),'productionSha256':hashlib.sha256((root/'Services/SafeDeleteFiles.cs').read_bytes()).hexdigest(),'dllSha256':hashlib.sha256(dll.read_bytes()).hexdigest(),'uniqueCommit':unique,'archiveExit':archived.returncode,'archiveStdout':archived.stdout,'archiveStderr':archived.stderr,'sourceWorktreeExists':tree.exists(),'archiveGitCalls':archive_calls,'environment':{k:env[k] for k in ['PATH','GIT_TERMINAL_PROMPT','GIT_OPTIONAL_LOCKS','MSBUILDDISABLENODEREUSE','DOTNET_CLI_USE_MSBUILD_SERVER','UseSharedCompilation']}}
    archive_root=main/'.git/dydo/safe-delete-archive'
    if archived.returncode==0:
        entry=next(p for p in archive_root.iterdir() if p.is_dir() and not p.name.startswith('.'))
        manifest=json.loads((entry/'manifest.json').read_text())
        result.update(complete=manifest['complete'],capturedTips=[t['oid'] for t in manifest['tips']],archivedNestedRef=(entry/'files/nested.git/packed-refs').read_text(),archivedAlternates=(entry/'files/nested.git/objects/info/alternates').read_text())
        assert unique not in result['capturedTips']
        git('gc','--prune=now');missing=run(['git','cat-file','-e',unique],expected=None)
        restored=run(['dotnet',dll,'archive','restore',entry.name],expected=None)
        check=run(['git','--git-dir',bare,'show','nested-unique:nested.txt'],expected=None)
        fsck=run(['git','--git-dir',bare,'fsck','--full'],expected=None)
        result.update(sourceUniqueCommitMissing=missing.returncode!=0,restoreExit=restored.returncode,nestedShowExit=check.returncode,nestedShowStderr=check.stderr,nestedFsckExit=fsck.returncode,nestedFsckStderr=fsck.stderr)
        assert missing.returncode!=0 and restored.returncode==0
        assert check.returncode==0,'DATA LOSS: archive/restore succeeded but nested unique work lost after source GC'
        assert expected!='refusal','Expected refusal before archive publication'
    else:
        assert archived.returncode==2
        assert 'Initialized nested repository' in archived.stdout+archived.stderr
        assert 'independent' in archived.stdout+archived.stderr
        assert before==snapshot(tree),'Refusal changed original files or modes'
        assert branches==git('show-ref') and trees==git('worktree','list','--porcelain')
        assert nested_refs==git('show-ref',cwd=bare)
        assert git('show','nested-unique:nested.txt',cwd=bare)=='ordinary shared clone unique work'
        complete=[p for p in archive_root.glob('*/manifest.json') if json.loads(p.read_text()).get('complete')]
        destructive=[call for call in archive_calls if ('worktree' in call['argv'] and 'remove' in call['argv']) or ('update-ref' in call['argv'] and '-d' in call['argv']) or ('push' in call['argv'])]
        assert not complete and not destructive
        result.update(allSourceFilesAndModesIntact=True,branchAndWorktreeRegistrationIntact=True,nestedRefsIntact=True,nestedUniqueCommitReadable=True,publishedCompleteEntries=len(complete),destructiveSubprocesses=destructive)
finally:
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if fixture.exists():shutil.rmtree(fixture)
    (out/'cleanup.json').write_text(json.dumps({'fixtureAbsent':not fixture.exists()})+'\n')
