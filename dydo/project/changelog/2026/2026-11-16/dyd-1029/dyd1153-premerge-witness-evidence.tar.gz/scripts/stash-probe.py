from pathlib import Path
import subprocess, json, os, shutil, hashlib

root=Path.cwd();out=Path('/tmp/dyd1153-merge-evidence');events=[]
fixture=out/'stash-conflict-fixture';main=fixture/'main';tree=fixture/'tree'
def run(args,cwd=root,expected=0):
    env={k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')}
    env.update(GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
    p=subprocess.run(args,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    events.append(dict(argv=list(map(str,args)),cwd=str(cwd),exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
    if expected is not None:assert p.returncode==expected,events[-1]
    return p
def git(cwd,*args,expected=0):return run(['git',*args],cwd,expected).stdout.strip()
try:
    assert git(root,'merge-base','--is-ancestor','f67a33df8990a8207e913e72972e58691898a60c','HEAD') == ''
    changed=run(['git','ls-files'],root).stdout.splitlines()
    sources={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in changed}
    dll=out/'artifacts/bin/DynaDocs/debug/dydo.dll'
    main.mkdir(parents=True)
    git(main,'init','-b','main');git(main,'config','user.name','Review');git(main,'config','user.email','review@example.invalid');git(main,'config','commit.gpgsign','false')
    (main/'file.txt').write_text('base\n');git(main,'add','.');git(main,'commit','-m','base')
    (main/'dydo.json').write_text('{"archive":{"reserveBytes":0,"reservePercent":0}}')
    git(main,'worktree','add','-b','topic',str(tree))
    (tree/'file.txt').write_text('unique stashed version\n');git(tree,'stash','push','-m','working change')
    stashBlob=git(tree,'rev-parse','stash:file.txt')
    (tree/'file.txt').write_text('committed topic version\n');git(tree,'add','file.txt');git(tree,'commit','-m','topic change')
    git(tree,'stash','pop',expected=1)
    (tree/'file.txt').write_text('resolved working version\n');git(tree,'add','file.txt');git(tree,'stash','drop')
    undo=git(tree,'ls-files','--resolve-undo');assert stashBlob in undo,undo
    before=git(tree,'show',stashBlob);assert before=='unique stashed version'
    p=run(['dotnet',str(dll),'archive','worktree',str(tree)],main,expected=None)
    entry=next(p for p in (main/'.git/dydo/safe-delete-archive').iterdir() if p.is_dir() and not p.name.startswith('.'))
    manifest=json.loads((entry/'manifest.json').read_text())
    packed=git(main,'verify-pack','-v',str(entry/'index-objects.idx'),expected=None) if (entry/'index-objects.idx').exists() else None
    git(main,'reflog','expire','--expire=now','--all');git(main,'gc','--prune=now')
    sourceMissingAfterGc=run(['git','cat-file','-e',stashBlob],main,expected=None).returncode!=0
    restored=run(['dotnet',str(dll),'archive','restore',entry.name],main,expected=None)
    missing=run(['git','cat-file','-e',stashBlob],tree,expected=None)
    after=git(tree,'ls-files','--resolve-undo')
    conflict=run(['git','checkout','-m','--','file.txt'],tree,expected=None)
    unmerged=git(tree,'ls-files','--unmerged',expected=None)
    result=dict(head=git(root,'rev-parse','HEAD'),sourceHashes=sources,dllSha256=hashlib.sha256(dll.read_bytes()).hexdigest(),
        archiveExit=p.returncode,restoreExit=restored.returncode,archiveComplete=manifest['complete'],archivedIndexEntries=manifest['indexEntries'],
        archivedResolveUndoEntries=manifest.get('resolveUndoEntries'),resolveUndoBefore=undo,resolveUndoAfter=after,stashedBlob=stashBlob,
        stashedBytesBefore=before,sourceMissingAfterGc=sourceMissingAfterGc,stashedBlobMissing=missing.returncode!=0,
        checkoutConflictExit=conflict.returncode,checkoutConflictError=conflict.stderr,unmergedAfterCheckout=unmerged,
        conflictFile=(tree/'file.txt').read_text(),fixtureRemoved=True)
    (out/'stash-conflict-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
finally:
    (out/'stash-conflict-events.json').write_text(json.dumps(events,indent=2)+'\n')
    if fixture.exists():shutil.rmtree(fixture)
