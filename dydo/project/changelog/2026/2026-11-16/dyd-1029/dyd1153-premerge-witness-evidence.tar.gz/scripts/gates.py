"""Sequential exact-head gates; each invocation uses the contracted capped wrapper."""
from pathlib import Path
import json
import subprocess
import sys
import shutil

out = Path('/tmp/dyd1153-final')
out.mkdir(exist_ok=False)
py = '.static-gates/python/bin/python'
facade = 'DynaDocs.Tests/coverage/gap_check.py'
light = 'FullyQualifiedName~SafeDelete|FullyQualifiedName~Clean|FullyQualifiedName~Git|FullyQualifiedName~Guard|FullyQualifiedName~BashCommandAnalyzer|FullyQualifiedName~DangerousPattern|FullyQualifiedName~InitCommandTests|FullyQualifiedName~Completion|FullyQualifiedName~Help|FullyQualifiedName~CommandSmoke|FullyQualifiedName~CommandDocConsistency|FullyQualifiedName~ReleaseWorkflow|FullyQualifiedName~WorkerLane'
focused = 'FullyQualifiedName~SafeDelete|FullyQualifiedName~WorkerLane|FullyQualifiedName~Guard'
commands = [
    ('discovery', ['dotnet','test','DynaDocs.Tests/DynaDocs.Tests.csproj','--list-tests','--filter',light]),
    ('focused', ['dotnet','test','DynaDocs.Tests/DynaDocs.Tests.csproj','--no-build','--filter',focused,'--logger','trx','--results-directory',str(out/'focused')]),
    ('light', ['dotnet','test','DynaDocs.Tests/DynaDocs.Tests.csproj','--no-build','--filter',light,'--logger','trx','--results-directory',str(out/'light')]),
    ('python-discovery', [py,'-m','unittest','discover','-s','DynaDocs.Tests/coverage/tests','-p','test_control_dydo.py','-v']),
    ('static', [py,facade,'gate','static','--stack','dotnet,python']),
    ('coverage', [py,facade,'gate','coverage','--stack','dotnet,python']),
    ('mutation', [py,facade,'gate','mutation','--since','dee4861ae2691e41d9e60985e3e0ffb0c7ea987d','--stack','dotnet,python']),
    ('check', ['dotnet','bin/Debug/net10.0/dydo.dll','check']),
]
summary=[]
for label, argv in commands:
    assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
    result = subprocess.run([sys.executable,'/tmp/dyd1029-run.py','dyd1153-final-'+label+'-01','gate',*argv])
    row={'label':label,'argv':argv,'exit':result.returncode}
    summary.append(row)
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    if label == 'discovery':
        log=Path('/tmp/dyd1029-runs/dyd1153-final-discovery-01/raw.log').read_text()
        for group in ['SafeDelete','GuardWorkerLaneTests','WorkerLaneClassificationTests','WorkerLaneSkillLintTests','CommandSmokeTests']:
            assert group in log, f'empty discovery: {group}'
    if label in ['static','coverage']:
        target=out/label
        target.mkdir()
        for stack in ['dotnet','python']:
            source=Path(f'DynaDocs.Tests/coverage/results/adapters/{stack}-{label}.json')
            if source.exists(): shutil.copyfile(source,target/source.name)
    if result.returncode != (2 if label == 'mutation' else 0):
        raise SystemExit(result.returncode or 1)
