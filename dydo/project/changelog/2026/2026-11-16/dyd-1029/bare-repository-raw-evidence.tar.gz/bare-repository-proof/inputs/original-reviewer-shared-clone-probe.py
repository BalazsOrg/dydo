from pathlib import Path
import subprocess,json,os,shutil
root=Path.cwd();out=Path('/tmp/dyd1029-r3-codex-review');fixture=out/'shared-clone-fixture'
main=fixture/'main';tree=fixture/'tree';bare=tree/'nested.git'
dll=root/'bin/codex-r3/artifacts/bin/DynaDocs/debug/dydo.dll';events=[];result={}
env={k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')}
env.update(GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
def run(argv,cwd=main,expected=0):
    p=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,text=True,capture_output=True)
    events.append({'argv':list(map(str,argv)),'cwd':str(cwd),'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    if expected is not None:assert p.returncode==expected,events[-1]
    return p
def git(*args,cwd=main,expected=0):return run(['git',*args],cwd,expected).stdout.strip()
try:
    main.mkdir(parents=True)
    git('init','-b','main');git('config','user.name','Review');git('config','user.email','review@example.invalid');git('config','commit.gpgsign','false')
    (main/'file.txt').write_text('base\n');git('add','.');git('commit','-m','base')
    git('switch','-c','nested-unique');(main/'nested.txt').write_text('ordinary shared clone unique work\n');git('add','nested.txt');git('commit','-m','unique nested work')
    unique=git('rev-parse','HEAD');git('switch','main')
    (main/'dydo.json').write_text('{"archive":{"reserveBytes":0,"reservePercent":0}}')
    git('worktree','add','-b','topic',tree)
    git('clone','--bare','--shared',main,bare)
    git('branch','-D','nested-unique')
    git('reflog','expire','--expire=now','--all')
    assert git('rev-parse','--is-bare-repository',cwd=bare)=='true'
    assert git('show','nested-unique:nested.txt',cwd=bare)=='ordinary shared clone unique work'
    assert not list((bare/'objects').glob('??/*')) and not list((bare/'objects/pack').iterdir())
    archived=run(['dotnet',dll,'archive','worktree',tree],expected=None)
    result={'candidate':git('rev-parse','HEAD',cwd=root),'uniqueCommit':unique,'archiveExit':archived.returncode,'sourceWorktreeExists':tree.exists()}
    if archived.returncode==0:
        entry=next(p for p in (main/'.git/dydo/safe-delete-archive').iterdir() if p.is_dir() and not p.name.startswith('.'))
        manifest=json.loads((entry/'manifest.json').read_text())
        result.update(complete=manifest['complete'],capturedTips=[t['oid'] for t in manifest['tips']],archivedNestedRef=(entry/'files/nested.git/packed-refs').read_text(),archivedAlternates=(entry/'files/nested.git/objects/info/alternates').read_text())
        assert unique not in result['capturedTips']
        git('gc','--prune=now');missing=run(['git','cat-file','-e',unique],expected=None)
        restored=run(['dotnet',dll,'archive','restore',entry.name],expected=None)
        check=run(['git','--git-dir',bare,'show','nested-unique:nested.txt'],expected=None)
        fsck=run(['git','--git-dir',bare,'fsck','--full'],expected=None)
        result.update(sourceUniqueCommitMissing=missing.returncode!=0,restoreExit=restored.returncode,nestedShowExit=check.returncode,nestedShowStderr=check.stderr,nestedFsckExit=fsck.returncode,nestedFsckStderr=fsck.stderr)
        assert missing.returncode!=0
        assert restored.returncode==0
        assert check.returncode==0,'DATA LOSS: archive and restore succeeded but shared nested repository lost its unique work after source GC'
    else:
        assert tree.exists(),'Refusal removed original tree'
finally:
    (out/'shared-clone-result.json').write_text(json.dumps(result,indent=2)+'\n')
    (out/'shared-clone-events.json').write_text(json.dumps(events,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if fixture.exists():shutil.rmtree(fixture)
