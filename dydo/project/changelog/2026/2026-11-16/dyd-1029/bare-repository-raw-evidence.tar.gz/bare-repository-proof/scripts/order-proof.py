from pathlib import Path
import subprocess,json,hashlib,os,xml.etree.ElementTree as ET

root=Path.cwd();source=root/'Services/SafeDeleteFiles.cs'
fixed=source.read_bytes()
after=b'                Walk(child, root, result);\n                RefuseNestedGitDirectory(child.FullName);'
before=b'                RefuseNestedGitDirectory(child.FullName);\n                Walk(child, root, result);'
assert fixed.count(after)==1
reverted=fixed.replace(after,before)
out=Path('/tmp/dyd1029-bare-fix-proof/order-revert-proof');out.mkdir(exist_ok=False)
rows=[]
try:
    for name,data,expected in [('green',fixed,0),('revert-red',reverted,1),('restored-green',fixed,0)]:
        assert source.read_bytes() in (fixed,reverted)
        source.write_bytes(data)
        paths=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z']).split(b'\0')
        hashes={os.fsdecode(raw):hashlib.sha256(Path(os.fsdecode(raw)).read_bytes()).hexdigest() for raw in paths if raw and Path(os.fsdecode(raw)).is_file()}
        results=out/name
        argv=['dotnet','test','DynaDocs.Tests/DynaDocs.Tests.csproj','--filter','FullyQualifiedName~NestedGitDirectory_ValidatesFileKindsBeforeGitDiscovery','--logger','trx','--results-directory',str(results)]
        row={'phase':name,'cwd':str(root),'argv':argv,'files':hashes,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'environment':{key:os.environ[key] for key in ['MSBUILDDISABLENODEREUSE','DOTNET_CLI_USE_MSBUILD_SERVER','UseSharedCompilation']}}
        with (out/(name+'.log')).open('w') as log:
            result=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
        row['exit']=result.returncode
        trx=next(results.glob('*.trx'))
        counters=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters')
        row['counters']=counters.attrib
        rows.append(row)
        assert result.returncode==expected,row
        assert counters.attrib['total']=='1' and counters.attrib['failed']==str(expected),row
finally:
    assert source.read_bytes() in (fixed,reverted)
    source.write_bytes(fixed)
    (out/'phases.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps([{key:row[key] for key in ['phase','exit','counters']} for row in rows],indent=2))
