"""Run from the candidate repository; all generated paths/labels are fresh and owned."""
from pathlib import Path
import subprocess,uuid,sys

scripts=Path(__file__).resolve().parent
label='bare-replay-'+uuid.uuid4().hex[:12]
artifacts='bin/'+label+'/artifacts'
wrapper=scripts/'run.py'
def run(suffix,level,*argv):
    subprocess.run([sys.executable,str(wrapper),label+'-'+suffix,level,*argv],check=True)
run('build','gate','dotnet','build','DynaDocs.csproj','--artifacts-path',artifacts,'-p:UseSharedCompilation=false')
run('witness','probe',sys.executable,str(scripts/'witness.py'),label,artifacts+'/bin/DynaDocs/debug/dydo.dll','refusal')
run('focused','gate','dotnet','test','DynaDocs.Tests/DynaDocs.Tests.csproj','--filter','FullyQualifiedName~SafeDelete','--logger','trx','--results-directory','/tmp/'+label+'/focused')
print('Replay passed:',label)
