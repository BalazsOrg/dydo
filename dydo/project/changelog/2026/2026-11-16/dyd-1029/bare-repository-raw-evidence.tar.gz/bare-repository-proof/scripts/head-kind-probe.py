import tempfile,os,subprocess,json
from pathlib import Path
with tempfile.TemporaryDirectory(prefix='dyd1029-head-kind-') as root:
    path=Path(root);(path/'objects').mkdir();(path/'refs').mkdir();os.mkfifo(path/'HEAD')
    argv=['git','rev-parse','--resolve-git-dir',str(path)]
    try:
        p=subprocess.run(argv,cwd=path,text=True,capture_output=True,timeout=2)
        result={'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'blockedOnHeadFifo':False}
    except subprocess.TimeoutExpired:
        result={'argv':argv,'blockedOnHeadFifo':True}
    Path('/tmp/dyd1029-bare-fix-proof/head-kind-probe.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
