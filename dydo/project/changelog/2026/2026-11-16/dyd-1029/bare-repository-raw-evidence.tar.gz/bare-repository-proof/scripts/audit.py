from pathlib import Path
import json,sys,hashlib,subprocess,xml.etree.ElementTree as ET,shutil

root=Path.cwd(); proof=Path('/tmp/dyd1029-bare-fix-proof')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
action=sys.argv[1]
if action=='discovery':
    label=sys.argv[2] if len(sys.argv)>2 else 'bare-fix-discovery-01'
    path=Path('/tmp/dyd1029-runs')/label/'raw.log'
    lines=path.read_text().splitlines()
    names=[line.strip() for line in lines if line.startswith('    ') and line.strip()]
    groups=['SafeDelete','Clean','Git','Guard','BashCommandAnalyzer','DangerousPattern','InitCommandTests','Completion','Help','CommandSmoke','CommandDocConsistency','ReleaseWorkflow']
    counts={group:sum(group in name for name in names) for group in groups}
    assert all(counts.values()), counts
    assert any('shared bare nested repository' in name for name in names)
    assert sum('InitializedNestedGitDirectory' in name for name in names)==6
    obj={'nativeListedTests':len(names),'groupCounts':counts,'executableSharedBareGherkinDiscovered':True,'raw':str(path),'rawSha256':digest(path)}
    (proof/(label+'-audit.json')).write_text(json.dumps(obj,indent=2)+'\n'); print(json.dumps(obj,indent=2))
elif action=='capture-gate':
    gate=sys.argv[2]
    adapter=root/f'DynaDocs.Tests/coverage/results/adapters/dotnet-{gate}.json'
    report=json.loads(adapter.read_text())
    print(json.dumps(report,indent=2)[:5000])
    target=proof/f'{gate}-assurance'
    target.mkdir(exist_ok=False)
    shutil.copy2(adapter,target/'adapter.json')
    runs=root/'DynaDocs.Tests/coverage/results/assurance'
    matches=[]
    for run in runs.glob('run-*'):
        for candidate in run.glob('*.json'):
            if candidate.name=='inventory.json':continue
            try: payload=json.loads(candidate.read_text())
            except (ValueError,UnicodeError):continue
            if payload==report:matches.append(run)
    assert len(set(matches))==1,matches
    source=matches[0]
    shutil.copytree(source,target/source.name)
    (target/'origin.json').write_text(json.dumps({'adapter':str(adapter),'immutableRun':str(source)},indent=2)+'\n')
elif action=='summary':
    rows=[]
    for run in sorted(Path('/tmp/dyd1029-runs').glob('bare-fix-*')):
        receipt=json.loads((run/'receipt.json').read_text())
        differences=[]
        for name,value in receipt['files'].items():
            if name.startswith('dydo/project/changelog/2026/2026-11-16/dyd-1029/'):continue
            path=root/name
            if path.is_file() and digest(path)!=value:differences.append(name)
        rows.append({'label':run.name,'exit':receipt.get('exit'),'argv':receipt['argv'],'head':receipt['head'],'sourceDifferencesFromFinal':differences,'receiptSha256':digest(run/'receipt.json'),'rawSha256':digest(run/'raw.log')})
    tests={}
    for path in proof.rglob('*.trx'):
        document=ET.parse(path);ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
        counters=document.find('.//t:Counters',ns)
        tests[str(path.relative_to(proof))]=dict(counters.attrib)
    obj={'runs':rows,'tests':tests,'finalSource':{name:digest(root/name) for name in subprocess.check_output(['git','diff','--name-only'],text=True).splitlines() if (root/name).is_file()},'finalStatus':subprocess.check_output(['git','status','--short'],text=True)}
    (proof/'summary.json').write_text(json.dumps(obj,indent=2)+'\n')
    print(json.dumps({'runs':[{k:row[k] for k in ['label','exit','sourceDifferencesFromFinal']} for row in rows],'tests':tests},indent=2))
