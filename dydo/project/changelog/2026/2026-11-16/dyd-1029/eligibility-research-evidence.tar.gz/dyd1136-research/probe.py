from pathlib import Path
import datetime, hashlib, json, subprocess, sys, urllib.request, urllib.error

ROOT = Path(__file__).resolve().parent

def save(name, value):
    (ROOT / name).write_text(value if isinstance(value, str) else json.dumps(value, indent=2) + '\n')

def gh(name, args):
    proc = subprocess.run(['gh', 'api', '--include', *args], capture_output=True, text=True)
    save(name + '.raw.txt', proc.stdout)
    save(name + '.stderr.txt', proc.stderr)
    save(name + '.command.json', {'argv': ['gh', 'api', '--include', *args], 'exit': proc.returncode, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(name, 'exit', proc.returncode, flush=True)
    if proc.returncode:
        print(proc.stderr[:1500], flush=True)
        return None
    body = proc.stdout.split('\r\n\r\n', 1)[-1] if '\r\n\r\n' in proc.stdout else proc.stdout.split('\n\n', 1)[-1]
    data = json.loads(body)
    save(name + '.json', data)
    return data

def graphql(name, query, variables=None):
    save(name + '.graphql', query)
    args = ['graphql', '-f', 'query=' + query]
    for key, value in (variables or {}).items():
        args += ['-F' if value is None or isinstance(value, (int, bool)) else '-f', key + '=' + ('null' if value is None else str(value).lower() if isinstance(value, bool) else str(value))]
    return gh(name, args)

def docs(name, path):
    url = 'https://docs.github.com/api/article/body?pathname=' + path
    try:
        with urllib.request.urlopen(url, timeout=25) as response:
            raw = response.read().decode()
            save(name + '.raw.json', raw)
            save(name + '.http.json', {'url': url, 'status': response.status, 'headers': dict(response.headers)})
        try:
            data = json.loads(raw)
            body = data.get('body', raw)
        except json.JSONDecodeError:
            body = raw
        save(name + '.md', body)
        print(name, 'ok', flush=True)
    except Exception as error:
        save(name + '.error.txt', repr(error))
        print(name, type(error).__name__, str(error), flush=True)

mode = sys.argv[1]
if mode == 'witness':
    pulls = gh('01-upstream-open-pulls', ['repos/cli/cli/pulls?state=open&per_page=30'])
    if pulls is None:
        sys.exit(1)
    candidates = [pr for pr in pulls if pr.get('head', {}).get('repo') and pr['head']['repo']['id'] != pr['base']['repo']['id']]
    assert candidates, 'No cross-fork witness; choose another upstream'
    pr = candidates[0]
    save('witness.json', {k: pr[k] for k in ('id', 'node_id', 'number', 'state', 'url', 'html_url', 'head', 'base')})
    repo = pr['head']['repo']
    query = '''query($owner:String!,$name:String!,$ref:String!,$cursor:String){
      repository(owner:$owner,name:$name){id databaseId nameWithOwner isPrivate viewerPermission
        ref(qualifiedName:$ref){id name prefix repository{id nameWithOwner} target{oid}
          associatedPullRequests(first:1,after:$cursor,states:[OPEN],orderBy:{field:CREATED_AT,direction:ASC}){
            totalCount pageInfo{hasNextPage endCursor}
            nodes{id number url state headRefName headRefOid headRepository{id databaseId nameWithOwner isPrivate}
              baseRefName baseRepository{id databaseId nameWithOwner isPrivate} repository{id nameWithOwner}}
          }
        }
      }
      rateLimit{cost remaining resetAt}
    }'''
    cursor = None
    seen = set()
    all_nodes = []
    for page in range(1, 101):
        response = graphql(f'02-head-associated-page-{page:03}', query, {'owner':repo['owner']['login'], 'name':repo['name'], 'ref':'refs/heads/' + pr['head']['ref'], 'cursor':cursor})
        assert response is not None and not response.get('errors'), 'API refused/incomplete'
        result = response['data']['repository']
        assert result['id'] == repo['node_id'] and result['databaseId'] == repo['id'] and result['nameWithOwner'].lower() == repo['full_name'].lower()
        ref = result['ref']
        assert ref and ref['name'] == pr['head']['ref'] and ref['prefix'] == 'refs/heads/' and ref['repository']['id'] == result['id']
        connection = ref['associatedPullRequests']
        for node in connection['nodes']:
            assert node['state'] == 'OPEN' and node['headRefName'] == ref['name'] and node['headRepository']['id'] == result['id']
        all_nodes.extend(connection['nodes'])
        if not connection['pageInfo']['hasNextPage']:
            break
        cursor = connection['pageInfo']['endCursor']
        assert cursor and cursor not in seen, 'Bad cursor'
        seen.add(cursor)
    else:
        raise RuntimeError('Page cap: incomplete/refuse')
    save('witness-summary.json', {'upstream_pr':pr['html_url'], 'head_repository':repo['full_name'], 'head_ref':pr['head']['ref'], 'head_repository_id':repo['node_id'], 'base_repository':pr['base']['repo']['full_name'], 'pages':page, 'returned':all_nodes, 'found_upstream_pr':any(n['id']==pr['node_id'] for n in all_nodes)})
    print((ROOT/'witness-summary.json').read_text(), flush=True)
elif mode == 'schema':
    graphql('03a-schema', '''query {
      ref:__type(name:"Ref"){name description fields{name description args{name description type{kind name ofType{kind name ofType{kind name}}}} type{kind name ofType{kind name}}}}
      repository:__type(name:"Repository"){name fields{name description args{name description type{kind name ofType{kind name}}} type{kind name ofType{kind name}}}}
    }''')
    graphql('03b-schema', '''query {
      connection:__type(name:"PullRequestConnection"){name description fields{name description type{kind name ofType{kind name}}}}
      pageInfo:__type(name:"PageInfo"){name description fields{name description type{kind name ofType{kind name}}}}
    }''')
elif mode == 'decode-docs':
    for path in ROOT.glob('docs-*.raw.json'):
        raw = path.read_text()
        try:
            body = json.loads(raw).get('body', raw)
        except json.JSONDecodeError:
            body = raw
        save(path.name.replace('.raw.json', '.md'), body)
elif mode == 'docs-extra':
    for name, path in [
      ('git','/en/graphql/reference/git'),
      ('branches','/en/graphql/reference/branches'),
      ('pull-requests','/en/graphql/reference/pull-requests'),
      ('queries','/en/graphql/reference/queries'),
      ('troubleshooting-new','/en/graphql/overview/troubleshooting'),
      ('pat-permissions','/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens'),
    ]:
        docs('docs-' + name, path)
elif mode == 'pagination-and-empty':
    query = '''query($cursor:String){repository(owner:"cli",name:"cli"){id nameWithOwner ref(qualifiedName:"refs/heads/trunk"){id name prefix repository{id nameWithOwner} target{oid} associatedPullRequests(first:7,after:$cursor,states:[OPEN],orderBy:{field:CREATED_AT,direction:ASC}){totalCount pageInfo{hasNextPage endCursor} nodes{id url state headRefName headRepository{id nameWithOwner} baseRepository{id nameWithOwner}}}}}}'''
    cursor = None
    seen = set()
    nodes = []
    expected_total = None
    for page in range(1,101):
        data = graphql(f'06-pagination-page-{page:03}', query, {'cursor':cursor})
        assert data and not data.get('errors')
        repository = data['data']['repository']
        ref = repository['ref']
        conn = ref['associatedPullRequests']
        if expected_total is None:
            expected_total = conn['totalCount']
        assert conn['totalCount'] == expected_total
        for node in conn['nodes']:
            assert node['id'] not in {n['id'] for n in nodes}
            assert node['state']=='OPEN' and node['headRefName']=='trunk' and node['headRepository']['id']==repository['id']
            nodes.append(node)
        if not conn['pageInfo']['hasNextPage']:
            break
        cursor=conn['pageInfo']['endCursor']
        assert cursor and cursor not in seen
        seen.add(cursor)
    else:
        raise RuntimeError('Page cap incomplete/refuse')
    assert len(nodes)==expected_total
    save('pagination-summary.json', {'repository':'cli/cli','ref':'refs/heads/trunk','per_page':7,'pages':page,'totalCount':expected_total,'nodes':nodes})
    print('Complete real pagination:', page, 'pages;', len(nodes),'nodes', flush=True)
    witness=json.loads((ROOT/'witness.json').read_text())
    repo=witness['head']['repo']
    graphql('07-existing-default-empty', '''query($owner:String!,$name:String!){repository(owner:$owner,name:$name){id databaseId nameWithOwner isPrivate defaultBranchRef{id name prefix repository{id nameWithOwner} target{oid} associatedPullRequests(first:100,states:[OPEN]){totalCount pageInfo{hasNextPage endCursor} nodes{id url state headRefName headRepository{id nameWithOwner}}}}}}''', {'owner':repo['owner']['login'],'name':repo['name']})
    graphql('08-missing-ref-alone', '''query($owner:String!,$name:String!){repository(owner:$owner,name:$name){id databaseId nameWithOwner ref(qualifiedName:"refs/heads/dyd1029-readonly-absent-785971749b44c2f7147e6250683a5b2ac43cf1e3"){id name}}}''', {'owner':repo['owner']['login'],'name':repo['name']})
elif mode == 'final-evidence':
    for name,path in [
      ('repos','/en/graphql/reference/repos'),
      ('pulls','/en/graphql/reference/pulls'),
      ('other','/en/graphql/reference/other'),
      ('rest-pagination','/en/rest/using-the-rest-api/using-pagination-in-the-rest-api'),
      ('rest-branches','/en/rest/branches/branches'),
    ]:
        docs('docs-'+name,path)
    witness=json.loads((ROOT/'witness.json').read_text())
    repo=witness['head']['repo']
    discovery=graphql('09-empty-ref-discovery', '''query($owner:String!,$name:String!){repository(owner:$owner,name:$name){id nameWithOwner defaultBranchRef{name} refs(refPrefix:"refs/heads/",first:100){pageInfo{hasNextPage endCursor} nodes{name associatedPullRequests(first:1,states:[OPEN]){totalCount pageInfo{hasNextPage endCursor} nodes{id}}}}}}''', {'owner':repo['owner']['login'],'name':repo['name']})
    assert discovery and not discovery.get('errors')
    r=discovery['data']['repository']
    candidates=[ref['name'] for ref in r['refs']['nodes'] if ref['name']!=r['defaultBranchRef']['name'] and ref['associatedPullRequests']['totalCount']==0]
    save('empty-nondefault-discovery.json', {'candidates':candidates,'discovery_exhaustive':not r['refs']['pageInfo']['hasNextPage']})
    if candidates:
        graphql('10-existing-nondefault-empty', '''query($owner:String!,$name:String!,$ref:String!){repository(owner:$owner,name:$name){id databaseId nameWithOwner isPrivate defaultBranchRef{name} ref(qualifiedName:$ref){id name prefix repository{id nameWithOwner} target{oid} associatedPullRequests(first:100,states:[OPEN]){totalCount pageInfo{hasNextPage endCursor} nodes{id url state headRefName headRepository{id nameWithOwner}}}}}}''', {'owner':repo['owner']['login'],'name':repo['name'],'ref':'refs/heads/'+candidates[0]})
elif mode == 'base-empty':
    witness=json.loads((ROOT/'witness.json').read_text())
    branch=json.loads((ROOT/'10-existing-nondefault-empty.json').read_text())['data']['repository']['ref']['name']
    repo=witness['head']['repo']
    seen=[]
    for page in range(1,101):
        data=gh(f'11-selected-repo-base-page-{page:03}', [f'repos/{repo["full_name"]}/pulls?state=open&per_page=100&page={page}'])
        assert isinstance(data,list)
        seen.extend(data)
        raw=(ROOT/f'11-selected-repo-base-page-{page:03}.raw.txt').read_text()
        if not any(line.lower().startswith('link:') and 'rel="next"' in line for line in raw.splitlines()):
            break
    else:
        raise RuntimeError('REST pagination cap incomplete/refuse')
    for pr in seen:
        assert pr['state']=='open'
        assert pr['base']['repo']['node_id']==repo['node_id']
        assert pr['base']['ref']!=branch
    save('base-empty-summary.json', {'repository':repo['full_name'],'branch':branch,'pages':page,'open_prs_seen':len(seen),'base_match':False})
    print('Base lookup completed:', page, 'pages;',len(seen),'PRs; no match')
elif mode == 'validate-contract':
    witness=json.loads((ROOT/'witness.json').read_text())
    repo=witness['head']['repo']
    empty=json.loads((ROOT/'10-existing-nondefault-empty.json').read_text())['data']['repository']['ref']
    query=(ROOT/'eligibility.graphql').read_text()
    for name,branch,expected_count in [
      ('12-contract-positive',witness['head']['ref'],1),
      ('13-contract-negative',empty['name'],0),
    ]:
        result=graphql(name,query,{'owner':repo['owner']['login'],'name':repo['name'],'qualifiedName':'refs/heads/'+branch,'first':100,'endCursor':None})
        assert result and not result.get('errors')
        r=result['data']['repository']
        assert r['id']==repo['node_id'] and r['nameWithOwner'].lower()==repo['full_name'].lower() and r['visibility']=='PUBLIC' and r['isPrivate'] is False
        ref=r['ref']
        assert ref['name']==branch and ref['prefix']=='refs/heads/' and ref['repository']['id']==repo['node_id']
        c=ref['associatedPullRequests']
        assert c['totalCount']==expected_count and len(c['nodes'])==expected_count and c['pageInfo']['hasNextPage'] is False
        if expected_count:
            assert c['nodes'][0]['id']==witness['node_id']
    help_result=subprocess.run(['gh','api','--help'],capture_output=True,text=True)
    save('gh-api-help.txt',help_result.stdout+help_result.stderr)
    print('Final contract query validated against positive and negative live cases')
elif mode == 'docs':
    pages = [
      ('objects','/en/graphql/reference/objects'),
      ('pagination','/en/graphql/guides/using-pagination-in-the-graphql-api'),
      ('limits','/en/graphql/overview/rate-limits-and-query-limits-for-the-graphql-api'),
      ('auth','/en/graphql/guides/forming-calls-with-graphql'),
      ('troubleshooting','/en/graphql/guides/troubleshooting'),
      ('rest-troubleshooting','/en/rest/using-the-rest-api/troubleshooting-the-rest-api'),
      ('fork-permissions','/en/pull-requests/collaborating-with-pull-requests/working-with-forks/about-permissions-and-visibility-of-forks'),
      ('pat','/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens'),
      ('rest-pulls','/en/rest/pulls/pulls'),
    ]
    for name, path in pages:
        docs('docs-' + name, path)
elif mode == 'absence':
    witness = json.loads((ROOT/'witness.json').read_text())
    repo = witness['head']['repo']
    graphql('04-missing-ref-and-repo', '''query($owner:String!,$name:String!){
      accessible:repository(owner:$owner,name:$name){id nameWithOwner ref(qualifiedName:"refs/heads/dyd1029-readonly-absent-785971749b44c2f7147e6250683a5b2ac43cf1e3"){id name}}
      unavailable:repository(owner:"github",name:"dyd1029-readonly-absent-785971749b44c2f7147e6250683a5b2ac43cf1e3"){id nameWithOwner}
    }''', {'owner':repo['owner']['login'], 'name':repo['name']})
    graphql('05-existing-no-pr-candidate', '''query{ repository(owner:"cli",name:"cli"){id nameWithOwner isPrivate ref(qualifiedName:"refs/heads/trunk"){id name prefix repository{id nameWithOwner} target{oid} associatedPullRequests(first:100,states:[OPEN]){totalCount pageInfo{hasNextPage endCursor} nodes{id url state headRefName headRepository{id nameWithOwner}}}}}}''')
elif mode == 'local':
    for name, args in [
        ('local-head',['git','rev-parse','HEAD']),
        ('default-governing',['git','show','origin/master:dydo/reference/linear-workspace-standard.md']),
        ('default-glossary',['git','show','origin/master:dydo/reference/dydo-glossary.md']),
        ('default-review-record',['git','show','origin/master:dydo/project/decisions/058-review-severities-blocker-should-nit.md']),
    ]:
        p = subprocess.run(args,capture_output=True,text=True)
        save(name+'.txt', p.stdout + p.stderr)
        print(name, p.returncode)
