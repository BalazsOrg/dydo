# DYD-1136 — authoritative cross-repository PR-head eligibility

Research crew / gpt-6.1-sol, high. Research performed 2026-11-17 UTC. Destination: DYD-1136 and return to DYD-1029 captain. Candidate boundary: `785971749b44c2f7147e6250683a5b2ac43cf1e3`; original base `dee4861ae2691e41d9e60985e3e0ffb0c7ea987d`. This is factual research and an implementable proposed validation contract, not production implementation or a scope/status decision.

## Question and answer

Can a fully paginated `HEAD_REPOSITORY.ref(qualifiedName: "refs/heads/<exact-name>").associatedPullRequests(states: [OPEN])` enumerate open PRs using that ref when their base is upstream or another fork?

**Yes: this is the official ref-head connection, and actual cross-repository results confirm both directions.** It is not a selected-base-repository list or a search-index lookup. Official docs and native API receipts support this route for cross-repository discovery. **A universal negative over private destinations with potentially restricted credentials remains unproved.** Neither the field description nor the public witness establishes how a hidden private PR affects connection membership or `totalCount`. Therefore a clean empty connection alone must not authorize a private-network delete when destination visibility is not authoritative. No product Question is needed to establish the cross-repository behavior; the remaining private-permission issue is technical evidence still owed, not an authorized local-only scope change.

What counted as an answer: official field/argument semantics, a real upstream PR returned from its fork's exact ref, a real traversal through its terminal page, and an explicit account of what absence/errors/permissions do and do not establish. All were investigated; restricted-private omission behavior was not proved.

## Load-bearing official sources

1. [GitHub GraphQL Git reference, Ref](https://docs.github.com/en/graphql/reference/git#object-ref): **“A list of pull requests with this ref as the head ref.”** `associatedPullRequests: PullRequestConnection!` accepts `first`, `after`, `states`, and `orderBy`; `states` is “A list of states to filter the pull requests by.” No upstream/base-repository constraint appears. Do not set additional base, head, label, or search filters. Native introspection independently agrees: `03a-schema.graphql`, `03a-schema.raw.txt`; connection/pageInfo schema: `03b-schema.graphql`, `03b-schema.raw.txt`. Earlier captain receipt `/tmp/dyd1029-runs/captain-ref-schema-01` agrees.
2. [Repositories reference, Repository](https://docs.github.com/en/graphql/reference/repos#object-repository): `ref(qualifiedName: String!): Ref` means “Fetch a given ref from the repository.” Its argument says fully qualified matches are checked before falling back to short-name matches. Therefore request `refs/heads/<name>` and validate returned `prefix`, exact `name`, and owning repository ID; never trust the request string alone. `isPrivate` includes private **and internal** repositories. `viewerPermission` describes permission on this repository, and can be null for a GitHub App; it is not an all-destination visibility attestation.
3. [Pull requests reference, PullRequest](https://docs.github.com/en/graphql/reference/pulls#object-pullrequest): `headRefName` and `headRefOid` remain available “even if the ref has been deleted”; `headRepository` and `baseRepository` are nullable. [PullRequestConnection](https://docs.github.com/en/graphql/reference/pulls#object-pullrequestconnection) exposes nullable nodes, `pageInfo`, and `totalCount` (“Identifies the total count of items in the connection”). No claim that this count includes inaccessible private PRs was found.
4. [Pagination](https://docs.github.com/en/graphql/guides/using-pagination-in-the-graphql-api): `first`/`last` must be **1–100**; continue with `pageInfo.endCursor` until `hasNextPage` is false. [PageInfo](https://docs.github.com/en/graphql/reference/other#object-pageinfo) defines those fields. This is a connection, not Search; no 1,000-result search cap is specified for this field. That is not a promise of unlimited service capacity or snapshot isolation.
5. [GraphQL limits](https://docs.github.com/en/graphql/overview/rate-limits-and-query-limits-for-the-graphql-api): at most 500,000 requested nodes per call; primary rate exhaustion can return HTTP 200 with an error; secondary limits can return 200/403; resource exhaustion can return **partial results plus an error**; documented processing timeout is currently 10 seconds, with 502/504 possible. Respect `Retry-After`/rate reset and reduce query size. Do not turn any failed or incomplete attempt into eligibility.
6. [Forming GraphQL calls](https://docs.github.com/en/graphql/guides/forming-calls-with-graphql): required scopes/permissions depend on the requested data; insufficient permissions cause errors. All fine-grained PATs have read access to public repositories. [PAT management](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens): a fine-grained token can be restricted to one resource owner and selected repositories. These general statements do **not** specify whether an inaccessible member of this particular cross-repository connection is omitted, null, counted, or reported as an error. The live witness used an OAuth credential advertising `repo` scope; this does not prove private-network-wide user access or limited-token behavior. No credential value was read or printed.
7. [Fork permissions and visibility](https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/working-with-forks/about-permissions-and-visibility-of-forks): public forks are public; private forks are private; permissions can differ; only team permissions, not individual permissions, are inherited by private forks. Visibility changes can disconnect networks. For a current ordinary public fork network, public-read authentication plus error-free completed traversal supports a public negative under those documented visibility rules. The public evidence does not settle restricted private/internal networks or historical cross-visibility associations.
8. [REST list pull requests](https://docs.github.com/en/rest/pulls/pulls#list-pull-requests): “Lists pull requests in a specified repository”; `state=open`, `base=<branch>` and `per_page` up to 100 are supported. It remains suitable for **bases in the selected repository**. [REST pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api) requires following `Link` pagination. [REST troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api#404-not-found-for-an-existing-resource): unauthenticated access to private resources can yield 404 to hide existence. Never interpret repository 404/NOT_FOUND as branch absence.

Exact fetched first-party Markdown and HTTP metadata are `docs-*.md`, `docs-*.raw.json` (some contain text/markdown despite the initial filename), and `docs-*.http.json` in this report's directory. The old `/reference/objects` and `/reference/queries` URLs now produced the reference index; the current topic pages above were fetched instead. The attempted troubleshooting GraphQL paths and `/reference/pull-requests` were 404; none is evidence for a successful lookup.

## Native live receipts

All files named below live under `/tmp/dyd1029-pr-eligibility-research-20261117/`. Each API request has exact argv/time/child exit in `*.command.json`, original HTTP headers/body in `*.raw.txt`, stderr in `*.stderr.txt`, and successful decoded responses in `*.json`. Queries are saved as `*.graphql`. No search endpoint was used.

### Upstream-base cross-fork witness

REST discovery `GET /repos/cli/cli/pulls?state=open&per_page=30` selected a real open PR, **https://github.com/cli/cli/pull/14783**, with:

* head repository `mrecachinas/cli`, node ID `R_kgDOVSfOWQ`, REST ID `1428672089`;
* head branch `release-download-verify`, OID `654d851d8145b2912fe474ceb0a47681854b37e2`;
* base repository `cli/cli`, node ID `MDEwOlJlcG9zaXRvcnkyMTI2MTMwNDk=`, REST ID `212613049`;
* PR node ID `PR_kwDODKw3uc8AAAABJ1z6Sw`.

`02-head-associated-page-001.graphql` queried **the head repository's** `ref(qualifiedName:"refs/heads/release-download-verify")`, `associatedPullRequests(first:1, states:[OPEN])`. HTTP 200, gh exit 0, no GraphQL errors, exact repository/ref identity matched, `totalCount:1`, terminal `hasNextPage:false`; its node was that upstream PR with the same head repository/name and different base repository. `witness-summary.json` records the assertion; `01-upstream-open-pulls.raw.txt`/`witness.json` preserve discovery. The discovery list was intentionally only a sample to choose a positive witness; no completeness conclusion uses that sample.

### Other-fork bases and actual exhaustive pagination

`06-pagination-page-001` through `005` queried `cli/cli`, `refs/heads/trunk`, `first:7`, `states:[OPEN]`, `orderBy:{field:CREATED_AT,direction:ASC}`. Returned page lengths were 7, 7, 7, 7, 2; each next request used the previous cursor; five pages terminated with `hasNextPage:false`. There were **30 unique PR IDs**, stable `totalCount:30`, and all heads identified `cli/cli:trunk`. The PR bases were other forks; for example `anhy999/cli-1#24`. `pagination-summary.json` preserves all 30 nodes and base identities. This is a real paginated connection, not an empty mock. `05-existing-no-pr-candidate` was an exploratory label: that query actually found these 30 PRs and **is not empty evidence**.

### Legitimate no-PR result

`10-existing-nondefault-empty` queried the existing nondefault ref:

`mrecachinas/cli:1119-support-for-owner-based-queries`, OID `e8cc7f94367a0d862501aea1e318e6e0c326f0b9`.

HTTP 200, gh exit 0; identified repository and ref; `prefix:"refs/heads/"`; `nodes:[]`, `totalCount:0`, `hasNextPage:false`, `endCursor:null`; no GraphQL errors. `11-selected-repo-base-page-001` independently listed this selected repository's open PRs with `per_page=100`: `[]`, no next-page Link, gh exit 0. The selected default branch is `trunk`. Thus this is a real successful public **head/base API check**, not blanket refusal. This research performed no Git deletion, fetch, archive, default-branch Git probe, or other production gate; it does not claim the entire archive command was eligible or executed.

`09-empty-ref-discovery` sampled the first 100 existing refs solely to choose that nondefault candidate; `hasNextPage:true`, explicitly recorded `discovery_exhaustive:false`. Nothing relies on completeness of branch discovery. `07-existing-default-empty` also returned a real zero connection, but its `trunk` ref is the default branch, independently protected from deletion.

### Missing branch versus unavailable repository; partial response

`08-missing-ref-alone`: querying a deliberately unique **uncreated** name inside the identified, accessible `mrecachinas/cli` returned HTTP 200, gh exit 0, no errors, correct repository ID, `ref:null`. It was not an empty associated-PR connection.

`04-missing-ref-and-repo`: one query included that accessible repository/missing ref and a deliberately nonexistent repository. GitHub returned HTTP 200 with useful `data.accessible`, `data.unavailable:null`, **and an `errors` array with `type:NOT_FOUND`**, gh exit **1**. This proves native partial-data/error handling is needed. This does not prove that an inaccessible existing private repository has precisely this response; the deliberately named repository was nonexistent. Official REST docs establish why 404 alone cannot distinguish hidden from absent resources. This whole mixed response must be refused; the separate clean probe is the usable branch-absence observation.

## Exact implementable proposed contract

Inputs: supported GitHub.com host, selected remote repository owner/name, exact validated branch name, immutable expected repository node ID resolved from that selected remote, and expected presence/OID from authoritative live Git remote discovery. Never infer the upstream repository or use a local tracking ref as the selected repository identity. Unsupported hosts refuse unless their API contract is separately proved. Source archive/deletion ordering and all non-PR protections stay governed by `fix-contract.txt`.

The executable query is `eligibility.graphql` in this directory. Validate its grammar with the accompanying recorded live probe before using it in production. Call using structured process arguments, for example:

```text
gh api --hostname github.com graphql
  -f query=<the complete eligibility.graphql file content>
  -f owner=<selected owner>
  -f name=<selected repository name>
  -f qualifiedName=refs/heads/<exact branch>
  -F first=100
  -F endCursor=null
```

This is an argv recipe, not shell interpolation. For subsequent pages pass the opaque returned cursor via `-f endCursor=<cursor>`; keep all other variables fixed. An explicit application loop gives page validation and budget control. `gh api --paginate` for GraphQL requires a named `$endCursor` variable and a `pageInfo` selection; if used instead, preserve every page (`--slurp`) and validate the terminal page and full GraphQL envelopes. Do not use `--jq`, Search, or an assumed last page as the success contract.

Return one of **Protected**, **EligibleAtObservation**, **RefAbsent**, or **Indeterminate** with a reason. `RefAbsent` is not shorthand for EligibleAtObservation. Positive protection can terminate immediately; a successful enumeration or negative requires all pages.

1. Any missing gh, spawn/timeout/network error, nonzero process exit, failed HTTP status, malformed/truncated JSON, nonempty GraphQL `errors`, null/missing `data` or repository, unexpected shape/type, null required node, or insufficient auth/SSO/app authorization => **Indeterminate**, nonzero command refusal; retain local and remote targets. Inspect envelope even with HTTP 200/exit 0. Never salvage partial data into eligibility. A valid positive PR also protects regardless of whether a later request would have failed.
2. Require returned repository ID and canonical `nameWithOwner`/URL host to match the selected repository identity. Compare GitHub owner/repository names case-insensitively and branch names ordinally. Refuse rename/transfer/name-reuse ambiguity rather than deleting through an unverified alias. Pin ID throughout all pages and the final check; an OID shared with an unrelated repository is insufficient identity. REST `repo.node_id` can corroborate GraphQL `id`; avoid narrowing large numeric IDs to 32 bits.
3. A present ref must have nonempty ID, `prefix == "refs/heads/"`, exact `name == branch`, `ref.repository.id == selected ID`, and nonnull target OID equal to the expected live remote tip. Tags, short-name fallback, another repository, a missing target, or movement/disappearance => **Indeterminate**. Node ID stability alone does not detect branch movement/recreation; validate OID and fresh presence too.
4. Require the connection, integer `totalCount >= 0`, array `nodes`, Boolean `hasNextPage`, and a valid cursor when another page exists. Validate every PR node's ID, `state == OPEN`, exact `headRefName`, and `headRepository.id == selected ID`. A valid match => **Protected** irrespective of base repository. Null identity or contradictory state/ref/repo => **Indeterminate**, never ignored. If desired validate `baseRepository.id == repository.id` for PR ownership; a null/mismatch is incomplete, not a safe unrelated PR. Do not filter by `headRefOid` to discard a PR: a stale/different OID cannot make this branch safe.
5. Start with `after:null`. If `hasNextPage:true`, require a nonempty, nonrepeated, advancing end cursor and fetch it. Reject empty nonterminal pages, duplicate PR IDs, impossible page sizes/counts, changing repository/ref/OID, changing totalCount, or terminal accumulated unique count differing from totalCount. Such checks detect inconsistencies but do not supply a transactional snapshot. `endCursor:null` is legitimate for an empty terminal connection. A short page alone does not prove completion.
6. **Page/budget strategy:** use 100 PR nodes per page, no expensive nested connections. No documented field-specific total cap was found. Proposed client ceiling: 100 pages / 10,000 PRs, bounded subprocess/deadline and response bytes; reaching any ceiling while a next page remains => **Indeterminate**, not truncation-as-success. These numbers are implementation policy, not GitHub guarantees or authorization to narrow scope. A legitimate positive can stop immediately. Rate-limit/abuse errors refuse this invocation; future retry respects server reset/Retry-After with bounded backoff. A smaller first value can reduce resource demand on retry; restart the traversal rather than mixing pages from a failed attempt. Probe execution here was sequential per pagination chain and below eight concurrent processes; no 429 occurred.
7. **Permission gate:** an empty, complete connection is only a negative within an authoritatively covered visibility domain. The ordinary current public-network case is supported by public fork visibility plus authenticated public-read access. For private/internal networks, credentials that can see only the head repository (including a fine-grained PAT or installation token), unknown possible base visibility, historical cross-visibility ambiguity, or any unproved hidden-member behavior => **Indeterminate**. Do not manufacture an `allForksVisible` API flag: no such GitHub API was established. `repo` scope, ADMIN on the selected repo, viewerPermission, `totalCount:0`, and “no errors” do not by themselves prove all private destinations visible.
8. **Absent-ref gate:** `repository` identified and error-free with `ref:null` can establish API absence at that observation. If Git expected a present branch/OID, refuse as disagreement/race. If Git also established absence, return **RefAbsent** explicitly and do not attempt remote deletion. This API cannot enumerate associations through a nonexistent Ref. Official PR schema preserves head name/OID after deletion; whether full contract permits local deletion in that situation requires an authoritative treatment of retained PR associations. Until that is supplied, retain the local target instead of translating `ref:null` into “no open PR anywhere.” Repository null/404/NOT_FOUND/auth error never qualifies as RefAbsent.
9. Independently paginate selected-repository REST `pulls?state=open&per_page=100` (or an exactly encoded base filter), following and validating next links until terminal. Validate `state`, `base.repo` node ID/canonical name, and exact base ref; a matching base => **Protected**. Any null/malformed identity or failure => **Indeterminate**. The REST list is not cross-repository head evidence. A head-negative plus base-negative still needs feature/default/T3/archive and all other commissioned gates.
10. Re-run the eligibility/identity/presence checks immediately before destructive work and keep the explicit expected-OID remote delete lease. GitHub provides no documented transaction that atomically locks PR creation/reopening/retargeting with a Git push-delete. A new PR can appear without changing the branch OID after the last query, so the lease does **not** close this race. Document the observation window; if the contract requires atomic no-PR-at-delete assurance, that stronger property is unproved by this route and needs resolution before claiming it.

## Regression matrix for the implementation author

These are proposed cases; this Research crew did not implement or run product tests. “Live” identifies native observations above, not archive/delete proof.

| Case | Required result / proof |
| --- | --- |
| Public fork head → upstream base, same exact ref | Protected; live `02` witness |
| Upstream head → another fork base | Protected; live `06` witness |
| Same head used in multiple destinations/pages | Every page reachable; any matching node protects; live 5-page/30-node traversal |
| Exact existing nondefault public ref, no heads, no bases | Head/base check succeeds after completeness validation; live `10`/`11`; all other deletion gates still required |
| Default branch with zero associated PRs | Remains protected; live `07` is API empty only |
| Same branch name in another repo; same commit in another ref; tag/short-name fallback | Must not conflate identities; unexpected association/ref shape refuses |
| Closed/merged PR only; draft OPEN PR | CLOSED/MERGED do not protect under OPEN contract; OPEN draft protects |
| Terminal empty, totalCount 0, null cursor | Legitimate API negative with identity/visibility gates, not malformed solely because cursor null |
| Match appears only after first 100 / multiple full pages | Protected, no first-page success |
| Missing/repeated cursor, empty nonterminal page, duplicate/null node, inconsistent count, page/byte/time cap | Indeterminate; local refs, remote refs and files intact |
| HTTP 200 with errors and partial useful data | Indeterminate; native live `04` supplies actual response |
| HTTP 401/403/404/429/5xx; rate error in 200; expired token/SSO; gh nonzero; malformed/truncated output | Indeterminate; no delete; server-directed retry only |
| Private/internal base hidden from head-only credential; null repository/PR/head/base identity | Indeterminate; do not claim a mocked empty connection establishes coverage |
| Correct accessible repository, absent exact ref | RefAbsent, not an empty connection; live `08`; expected-present mismatch refuses |
| Missing/inaccessible repository | Indeterminate; never branch-absent; `04` and official 404 docs |
| Ref absent but retained PR head name/OID | Preserve local target until authoritative policy/API treatment supplied |
| Repo renamed/transferred/replaced, canonical identity disagreement | Indeterminate; compare pinned immutable repository IDs |
| Branch moved/disappeared/recreated during pagination/final check | Indeterminate; verify identity/presence/OID and lease |
| PR opens/reopens/retargets after final read without OID movement | Explicit API/Git atomicity limitation; do not claim lease prevents it |
| REST base match in selected repository, foreign same-name head | Base match protects; foreign head never substitutes for selected head identity |
| REST base lookup is incomplete/fails after head negative | Indeterminate, local target retained |

## What remains unsettled; prepared return options

**Established:** official ref-head semantics, upstream and other-fork positive witnesses, real full pagination, real existing nondefault empty head/base lookup, distinguishable branch absence inside an accessible repository, and actual partial-data/error behavior. This is sufficient to prepare the precise cross-repository API route without inventing an API or asking a product Question about whether cross-fork enumeration exists.

**Not established:** field-specific omission/error/count behavior when a private destination is invisible; exact minimal fine-grained GraphQL permission set for this field (REST pull-request read permission alone is not a proved GraphQL recipe); exhaustive private destination coverage with arbitrary selected-repository credentials; a safe retained-PR treatment when Ref is absent; historical cross-visibility edge cases; atomic PR-state/Git deletion. No private witness or limited-token A/B experiment was performed, no absent repository was misrepresented as an inaccessible-private witness, and no 401/429/resource-limit failure was deliberately induced.

If the captain needs one route established for **every** commissioned private/absent-ref case before implementation can proceed, return to the admiral with these prepared options, without selecting either:

* Retain full scope and continue targeted factual research: obtain GitHub's field-specific guarantee or a pre-existing controlled private-network witness with credential A/B visibility, and settle absent-ref retained associations. Creating refs/PRs or new credentials was outside this Research brief. Meanwhile refuse only cases whose authority cannot be proved; do not present public evidence as universal private proof.
* Explicitly authorize shipping local-only behavior as a product scope change. No such authorization exists here; this report does not choose or implement it.

The first option can use the now-proved cross-repository connection rather than search. A separate factual investigation may be enough; captain/admiral own that routing and every status.

## Families searched and execution accounting

* Governing: live user brief and DYD-1136 description; `fix-contract.txt` with its Q3 head/base/failed-lookup rule; default-branch DR058, workspace communication protocol, glossary. Read-only local `origin/master` records were used; no remote fetch or assertion that this tracking ref was freshly synchronized. No governing record changes these API semantics.
* dydo: required `about.md`, `architecture.md`, root index and Research skill. Broader historical plans/glossary topics cannot own GitHub connection behavior; no unrelated documentation survey.
* Code/tests: read `Services/SafeDeleteGitHub.cs` at the commissioned candidate boundary; its unconditional cross-repository refusal explains the live problem. No production edits or test implementation. No adjacent service investigation.
* Git/history: confirmed local HEAD and clean status; candidate/base pins came from brief. Default governing blobs were read, not branch histories exhaustively mined; Git history cannot establish live GitHub resolver behavior.
* External: official GitHub docs, official live schema, native read-only REST/GraphQL. No Search, community answer, mock completeness claim, or API invented from naming.

All executable API/docs probes used `/tmp/dyd1029-run.py <fresh-label> probe python3 ...` → shared `/var/tmp/dydo-gate-lock.sh` → `systemd-run --user --scope` in the nearest user agent slice with `MemoryMax=4G`, `MemorySwapMax=0`, `OOMPolicy=continue`, `timeout 120`. The helper launches a separate scope outside the invoking agent scope; exact scope/argv/start/end/exit are in run receipts. First sandbox attempt failed at the user bus and was retained; subsequent probes used the same capped command through authorized escalation, never an uncapped fallback. No .NET execution was relevant; helper set the commissioned .NET environment variables anyway.

`pr-eligibility-research-schema-01` wrapper exited 0 but its gh child exited 1: GitHub rejects more than two `__Type.fields` introspection uses in one request. This is not successful schema evidence. It was corrected into two smaller queries (`schema-02`, both gh exit 0). Initial docs extraction expected JSON but received Markdown; original bytes were preserved, then decoded correctly. These preparation failures are retained, not counted as successful API proof.

Raw runner receipts/logs, file hashes, requested resource limits, final repository status and evidence index are preserved alongside this report. No production refs, code, ticket statuses, commits, pushes, PRs, or additional crew were changed or created. Only the explicitly requested DYD-1136 evidence post is a remote write.
