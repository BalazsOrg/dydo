from pathlib import Path
import base64, hashlib, json, re, shutil, subprocess, tarfile

root=Path(__file__).resolve().parent
receipts=root/'run-receipts'
receipts.mkdir(exist_ok=True)
runs=[]
for run in sorted(Path('/tmp/dyd1029-runs').glob('pr-eligibility-research-*')):
    if not (run/'receipt.json').exists():
        continue
    data=json.loads((run/'receipt.json').read_text())
    if 'exit' not in data:
        continue
    shutil.copytree(run,receipts/run.name,dirs_exist_ok=True)
    runs.append({'label':run.name,**{k:v for k,v in data.items() if k!='files'},'tracked_and_untracked_file_count':len(data['files'])})
cgroup=Path('/proc/self/cgroup').read_text().strip()
cgpath=Path('/sys/fs/cgroup')/cgroup.split('::',1)[-1].lstrip('/')
limits={}
for name in ['memory.max','memory.swap.max','memory.oom.group']:
    path=cgpath/name
    limits[name]=path.read_text().strip() if path.exists() else 'unavailable'
status=subprocess.check_output(['git','status','--porcelain'],text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not status, 'Unexpected production worktree changes'
assert head=='785971749b44c2f7147e6250683a5b2ac43cf1e3'
execution={'runs':runs,'packaging_cgroup':cgroup,'packaging_effective_limits':limits,'final_head':head,'final_git_status_porcelain':status}
(root/'run-execution.json').write_text(json.dumps(execution,indent=2)+'\n')

index={}
for path in sorted(root.rglob('*')):
    if not path.is_file() or path.name in ['evidence-index.json','evidence-core.tar.gz','attachment-upload.json']:
        continue
    content=path.read_bytes()
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|Authorization: (?:token|bearer) [A-Za-z0-9_]{20,})',content), 'Credential-like material detected; refusing package'
    index[str(path.relative_to(root))]={'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)}
(root/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')

selected=[]
for path in root.iterdir():
    n=path.name
    if not path.is_file():
        continue
    if n in ['report.md','eligibility.graphql','probe.py','package.py','witness.json','witness-summary.json','pagination-summary.json','base-empty-summary.json','run-execution.json','evidence-index.json','gh-api-help.txt']:
        selected.append(path)
    elif n.startswith('docs-') and n.endswith('.md'):
        selected.append(path)
    elif n.endswith(('.raw.txt','.command.json','.graphql','.stderr.txt')) and not n.startswith(('01-','09-')):
        selected.append(path)
with tarfile.open(root/'evidence-core.tar.gz','w:gz') as archive:
    for path in sorted(selected):
        archive.add(path,arcname='dyd1136-research/'+path.name)
    for run in sorted(receipts.iterdir()):
        log=run/'raw.log'
        if log.exists():
            archive.add(log,arcname='dyd1136-research/run-logs/'+run.name+'.log')
bundle=(root/'evidence-core.tar.gz').read_bytes()
digest=hashlib.sha256(bundle).hexdigest()
upload={'issue':'DYD-1136','filename':'dyd1136-pr-head-research-evidence.tar.gz','contentType':'application/gzip','title':'Research evidence — cross-repository PR-head API','subtitle':'Read-only native receipts, official docs, exact query and validation contract; private visibility remains unproven.','size':len(bundle),'sha256':digest,'base64Content':base64.b64encode(bundle).decode()}
assert hashlib.sha256(base64.b64decode(upload['base64Content'])).hexdigest()==digest
(root/'attachment-upload.json').write_text(json.dumps(upload))
print(json.dumps({'files_indexed':len(index),'core_archive_bytes':len(bundle),'core_archive_sha256':digest,'completed_runs':len(runs),'final_head':head,'git_status_clean':not status,'scope':cgroup,'effective_limits':limits},indent=2))
