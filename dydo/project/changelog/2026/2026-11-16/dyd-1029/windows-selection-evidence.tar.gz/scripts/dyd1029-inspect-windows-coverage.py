from pathlib import Path
import json
import xml.etree.ElementTree as ET

root=Path('/home/balazs/.cache/agent-scratch/dydo-370-admiral/art-win2')
coverage=next(root.glob('assurance/*/raw-*/raw/coverage.opencover.xml'))
tree=ET.parse(coverage)
for module in tree.findall('.//Module'):
    files={f.attrib['uid']:f.attrib['fullPath'] for f in module.findall('./Files/File')}
    ids={k for k,v in files.items() if v.replace('\\','/').endswith('/Services/SafeDeleteWindowsMetadata.cs')}
    if not ids:
        continue
    for method in module.findall('.//Method'):
        points=[p.attrib for p in method.findall('./BranchPoints/BranchPoint') if p.attrib.get('fileid') in ids]
        if points:
            print(json.dumps({'method':method.findtext('Name'),'branches':points}))
