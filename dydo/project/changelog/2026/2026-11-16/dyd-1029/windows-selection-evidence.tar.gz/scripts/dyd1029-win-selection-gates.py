"""Sequential gate recipe for the narrow Windows selection correction."""
from pathlib import Path
import json
import subprocess
import sys

phase = sys.argv[1]
run_tag = sys.argv[2] if len(sys.argv) > 2 else '01'
out = Path('/tmp/dyd1029-windows-selection-proof' if run_tag == '01' else '/tmp/dyd1029-windows-selection-replay-' + run_tag)
out.mkdir(exist_ok=True)
light = 'FullyQualifiedName~SafeDelete|FullyQualifiedName~Clean|FullyQualifiedName~Git|FullyQualifiedName~Guard|FullyQualifiedName~BashCommandAnalyzer|FullyQualifiedName~DangerousPattern|FullyQualifiedName~InitCommandTests|FullyQualifiedName~Completion|FullyQualifiedName~Help|FullyQualifiedName~CommandSmoke|FullyQualifiedName~CommandDocConsistency|FullyQualifiedName~ReleaseWorkflow|FullyQualifiedName~WorkerLane|FullyQualifiedName~Statechart'
selection = json.loads(Path('DynaDocs.Tests/coverage/dotnet-platforms.json').read_text())
windows = '|'.join('FullyQualifiedName=' + name for name in selection['windows_tests']['tests'])
base = ['dotnet', 'test', 'DynaDocs.Tests/DynaDocs.Tests.csproj']
commands = {
    'windows-discovery': [*base, '--list-tests', '--filter', windows],
    'light-discovery': [*base, '--no-build', '--list-tests', '--filter', light],
    'light': [*base, '--no-build', '--filter', light, '--logger', 'trx', '--results-directory', str(out / 'light')],
    'static': ['.static-gates/python/bin/python', 'DynaDocs.Tests/coverage/gap_check.py', 'gate', 'static', '--stack', 'dotnet,python'],
}
label = 'win-selection-' + phase + '-' + run_tag
command = commands[phase]
result = subprocess.run([sys.executable, str(Path(__file__).with_name('dyd1029-run.py')), label, 'gate', *command], check=False)
if result.returncode:
    raise SystemExit(result.returncode)
log = Path('/tmp/dyd1029-runs') / label / 'raw.log'
text = log.read_text()
if phase == 'windows-discovery':
    found = {name: text.count(name) for name in selection['windows_tests']['tests']}
    assert all(count > 0 for count in found.values()), found
    (out / 'windows-discovery.json').write_text(json.dumps(found, indent=2) + '\n')
    print('Native assembly discovery: all 17 selected methods have nonzero discovery; no Windows runtime claim.')
elif phase == 'light-discovery':
    groups = ['SafeDelete', 'Clean', 'Git', 'Guard', 'BashCommandAnalyzer', 'DangerousPattern', 'InitCommandTests', 'Completion', 'Help', 'CommandSmoke', 'CommandDocConsistency', 'ReleaseWorkflow', 'WorkerLane', 'Statechart']
    found = {name: sum(name in line for line in text.splitlines()) for name in groups}
    assert all(count > 0 for count in found.values()), found
    assert 'Archive' in text and 'SafeDelete' in text
    (out / 'light-discovery.json').write_text(json.dumps(found, indent=2) + '\n')
    print('All 14 own/reached Light groups have nonzero discovery.')
