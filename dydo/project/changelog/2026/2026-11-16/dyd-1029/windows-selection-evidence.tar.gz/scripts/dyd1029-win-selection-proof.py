"""Read-only selection witness; writes only its fresh, named proof directory."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
OUT = Path('/tmp/dyd1029-windows-selection-proof')
TEST = 'DynaDocs.Tests.Integration.SafeDeleteBoundaryTests.WindowsStreamMetadata_AcceptsDefaultStreamsAndRefusesAlternateStreams'
SELECTION = Path('DynaDocs.Tests/coverage/dotnet-platforms.json')
SOURCE = Path('Services/SafeDeleteWindowsMetadata.cs')
BOUNDARY = Path('DynaDocs.Tests/Integration/SafeDeleteBoundaryTests.cs')
ARTIFACT = Path('/home/balazs/.cache/agent-scratch/dydo-370-admiral/art-win2')
HEAD = '46e378be3b19cdacfc46ec301e8fdcbce1c848bb'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, value):
    path = OUT / name
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

mode = sys.argv[1]
selection = json.loads(SELECTION.read_text())
if mode == 'before':
    OUT.mkdir(exist_ok=False)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    summary = json.loads(Path('/tmp/dyd1029-captain-native-t3-46e378b/summary.json').read_text())
    ready = json.loads(Path('/tmp/dyd1029-runs/captain-integrated-pr-ready-02/receipt.json').read_text())
    assert summary['candidate'] == HEAD and summary['retainedStateEqual'] is True
    assert ready['head'] == HEAD and ready['exit'] == 0
    assert TEST not in selection['windows_tests']['tests']
    report_path = ARTIFACT / 'adapters/dotnet-coverage.json'
    report = json.loads(report_path.read_text())
    assert report['exitCode'] == 1 and report['measurementComplete'] is True
    assert report['collectors']['csharp-coverage']['facts']['child_exit'] == 0
    assert len(report['findings']) == 1
    finding = report['findings'][0]
    assert finding['path'] == SOURCE.as_posix() and finding['gate'] == 'branch-coverage'
    assert finding['threshold'] == 60 and 59.09 < finding['actual'] < 59.10
    preflight = json.loads((ARTIFACT / 'preflight.json').read_text())
    assert preflight['pr_head_sha'] == HEAD and TEST not in preflight['tests']
    assert list(preflight['tests']) == selection['windows_tests']['tests']
    assert digest(SOURCE) == selection['native'][SOURCE.as_posix()]['sha256']
    raw = next(ARTIFACT.glob('assurance/*/raw-*/raw/coverage.opencover.xml'))
    document = ET.parse(raw)
    branches = []
    for module in document.findall('.//Module'):
        files = {f.attrib['uid']: f.attrib['fullPath'] for f in module.findall('./Files/File')}
        ids = {k for k, v in files.items() if v.replace('\\', '/').endswith('/' + SOURCE.as_posix())}
        for method in module.findall('.//Method'):
            points = [p.attrib for p in method.findall('./BranchPoints/BranchPoint') if p.attrib.get('fileid') in ids]
            if points:
                branches.append({'method': method.findtext('Name'), 'branches': points})
    check_streams = next(row for row in branches if '::CheckStreams(' in row['method'])
    assert any(int(point['vc']) == 0 for point in check_streams['branches'])
    body = BOUNDARY.read_text().split('    public void WindowsStreamMetadata_AcceptsDefaultStreamsAndRefusesAlternateStreams()', 1)[1].split('\n    [Theory]', 1)[0]
    assert 'if (!OperatingSystem.IsWindows()) return;' in body
    assert 'File.WriteAllText(file + ":hidden","alternate stream\\n");' in body
    assert 'Assert.Contains("Alternate Windows streams",Assert.Throws<InvalidDataException>' in body
    write('before-selection.json', selection)
    write('native-red.json', {
        'artifact': json.loads((ARTIFACT / 'artifact-identity.json').read_text()),
        'candidate': report['candidate'], 'head': HEAD, 'measurementComplete': True,
        'child_exit': 0, 'exitCode': 1, 'findings': report['findings'],
        'sourceSha256': digest(SOURCE), 'boundarySha256': digest(BOUNDARY),
        'selectionSha256': digest(SELECTION), 'nativeBranches': branches,
        'existingTestBody': body, 'testSelectedBefore': False,
        'raw': {str(path): digest(path) for path in [report_path, raw, ARTIFACT / 'preflight.json', ARTIFACT / 'artifact-identity.json']},
        'handoff': {'candidate': summary['candidate'], 'retainedStateEqual': True, 'prReadyExit': 0},
    })
    commands = [['dotnet', '--version'], ['dotnet', '--list-runtimes'], ['dotnet', 'tool', 'list', '--local'], ['git', '--version'], [str(ROOT / '.static-gates/python/bin/python'), '--version']]
    versions = [{'argv': command, 'stdout': subprocess.check_output(command, text=True)} for command in commands]
    write('prerequisites.json', {'python': platform.python_version(), 'versions': versions})
    print('Native RED: branch coverage 59.09090909 < 60, child_exit 0; meaningful existing NTFS test omitted from 16-method selection.')
elif mode == 'after':
    sys.path.insert(0, str(ROOT / 'DynaDocs.Tests/coverage'))
    import dotnet_platform
    before = json.loads((OUT / 'before-selection.json').read_text())
    native = json.loads((OUT / 'native-red.json').read_text())
    assert selection['native'] == before['native']
    assert selection['windows_tests']['tests'] == before['windows_tests']['tests'] + [TEST]
    assert {k: v for k, v in selection.items() if k != 'windows_tests'} == {k: v for k, v in before.items() if k != 'windows_tests'}
    assert selection['windows_tests']['reason'] == before['windows_tests']['reason']
    assert digest(SOURCE) == native['sourceSha256'] and digest(BOUNDARY) == native['boundarySha256']
    for target in ('linux', 'windows'):
        dotnet_platform.load_selection(ROOT, target)
    discovered = dotnet_platform.discover_windows_tests(ROOT, selection)
    assert len(discovered) == 17 and discovered[TEST] == BOUNDARY.as_posix()
    write('after-selection.json', selection)
    write('selection-check.json', {'added': TEST, 'declared': discovered, 'filter': dotnet_platform.windows_filter(selection), 'sourceSha256': digest(SOURCE), 'boundarySha256': digest(BOUNDARY), 'nativeRuntimeProof': 'PENDING: hosted Windows required; Linux early return is not NTFS proof'})
    print('Selection GREEN: exactly one existing NTFS test added; all 17 declarations resolve; source/member pins and test bytes unchanged. Native Windows floor remains pending.')
else:
    raise ValueError(mode)
