"""Validate and preserve this hop's raw receipts without rewriting earlier evidence."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path.cwd()
out = Path('/tmp/dyd1029-windows-selection-proof')
destination = root / 'dydo/project/changelog/2026/2026-11-16/dyd-1029/windows-selection-evidence.tar.gz'
head = '46e378be3b19cdacfc46ec301e8fdcbce1c848bb'
changed = {'DynaDocs.Tests/coverage/dotnet-platforms.json', 'DynaDocs.Tests/coverage/tests/test_dotnet_platform.py'}
artifact = Path('/home/balazs/.cache/agent-scratch/dydo-370-admiral/art-win2')
native = json.loads((artifact / 'adapters/dotnet-coverage.json').read_text())
before = json.loads((out / 'before-selection.json').read_text())
selection = json.loads((root / 'DynaDocs.Tests/coverage/dotnet-platforms.json').read_text())
facts = native['collectors']['csharp-coverage']['facts']['platform_selection']
assert facts['selection_sha256'] == hashlib.sha256(json.dumps(before, sort_keys=True).encode()).hexdigest()
assert facts['sources']['Services/SafeDeleteWindowsMetadata.cs'] == before['native']['Services/SafeDeleteWindowsMetadata.cs']['sha256']
assert selection['native'] == before['native']
assert len(selection['windows_tests']['tests']) == len(before['windows_tests']['tests']) + 1
native_red = json.loads((out / 'native-red.json').read_text())
stream_branches = next(row['branches'] for row in native_red['nativeBranches'] if '::CheckStreams(' in row['method'])
assert any(point['sl'] == '48' and point['path'] == '0' and point['vc'] == '0' for point in stream_branches)
raw_native = next(artifact.glob('assurance/*/raw-*/raw/coverage.opencover.xml'))
xml_artifact = next(row for row in native['collectors']['csharp-coverage']['artifacts'] if row['path'].endswith('/coverage.opencover.xml'))
assert hashlib.sha256(raw_native.read_bytes()).hexdigest() == xml_artifact['sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == head
assert set(subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()) == changed

labels = ['before', 'after', 'platform', 'windows-discovery', 'light-discovery', 'light', 'static']
receipts = {}
baseline = json.loads(Path('/tmp/dyd1029-runs/win-selection-before-01/receipt.json').read_text())
for label in labels:
    folder = Path('/tmp/dyd1029-runs') / ('win-selection-' + label + '-01')
    receipt = json.loads((folder / 'receipt.json').read_text())
    assert receipt['head'] == head and receipt['exit'] == 0
    assert receipt['argv'][:2] == ['/var/tmp/dydo-gate-lock.sh', 'env']
    assert '--slice=app-t3code-agents-cbc6c2286251.slice' in receipt['argv']
    assert 'MemorySwapMax=0' in receipt['argv'] and 'OOMPolicy=continue' in receipt['argv']
    expected_cap = 'MemoryMax=4G' if label in ('before', 'after', 'platform') else 'MemoryMax=8G'
    assert expected_cap in receipt['argv']
    differences = {path for path, value in baseline['files'].items() if receipt['files'].get(path) != value}
    assert differences == (set() if label == 'before' else changed), (label, differences)
    for path in changed:
        if label != 'before':
            assert receipt['files'][path] == hashlib.sha256((root / path).read_bytes()).hexdigest()
    receipts[label] = {'head': head, 'exit': receipt['exit'], 'status': receipt['status'], 'argv': receipt['argv'], 'changedFromCleanParent': sorted(differences)}

trx = next((out / 'light').glob('*.trx'))
document = ET.parse(trx)
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
counters = document.find('.//t:Counters', ns).attrib
assert int(counters['failed']) == 0 and int(counters['passed']) > 4000
assert any('WindowsStreamMetadata_AcceptsDefaultStreamsAndRefusesAlternateStreams' in row.attrib.get('testName', '') for row in document.findall('.//t:UnitTestResult', ns))
adapters = {}
static_dir = out / 'static'
static_dir.mkdir(exist_ok=False)
for stack in ('dotnet', 'python'):
    path = root / 'DynaDocs.Tests/coverage/results/adapters' / (stack + '-static.json')
    report = json.loads(path.read_text())
    assert report['exitCode'] == 0 and report['measurementComplete'] is True
    assert not report['findings'] and not report['gaps']
    assert report['candidate']['commit'] == head and report['candidate']['dirty'] is True
    shutil.copyfile(path, static_dir / path.name)
    adapters[stack] = {key: report[key] for key in ('candidate', 'exitCode', 'measurementComplete', 'findings', 'gaps', 'inventory')}

audit = {'parent': head, 'changedSourcePaths': sorted(changed), 'gateReceipts': receipts,
         'lightCounters': counters, 'nativeMeasuredSourceSha256': facts['sources']['Services/SafeDeleteWindowsMetadata.cs'],
         'nativeOldSelectionSha256': facts['selection_sha256'], 'nativeMeasuredTests': facts['tests'],
         'static': adapters, 'nativeSuccessor': 'PENDING captain-owned Windows floor and platform union',
         'mutation': 'NOT RUN in this writer hop; reviewer-owned inherited exit 2 UNAVAILABLE DYD-103, non-holding, never PASS'}
with (out / 'audit.json').open('x') as stream:
    json.dump(audit, stream, indent=2)
    stream.write('\n')

with tarfile.open(destination, 'x:gz') as bundle:
    for path in sorted(out.rglob('*')):
        if path.is_file():
            bundle.add(path, arcname='proof/' + path.relative_to(out).as_posix())
    for label in labels:
        folder = Path('/tmp/dyd1029-runs') / ('win-selection-' + label + '-01')
        for name in ('receipt.json', 'raw.log'):
            bundle.add(folder / name, arcname='runs/' + folder.name + '/' + name)
    for name in ('dyd1029-win-selection-proof.py', 'dyd1029-win-selection-gates.py', 'dyd1029-win-selection-seal.py', 'dyd1029-run.py', 'dyd1029-inspect-windows-coverage.py'):
        bundle.add(Path('/tmp') / name, arcname='scripts/' + name)
    for name in ('artifact-identity.json', 'preflight.json', 'adapters/dotnet-coverage.json'):
        bundle.add(artifact / name, arcname='native/' + name)
    bundle.add(raw_native, arcname='native/coverage.opencover.xml')
    bundle.add(raw_native.with_name('windows-tests.trx'), arcname='native/windows-tests.trx')
    for stack, report in adapters.items():
        run_directory = root / 'DynaDocs.Tests/coverage/results' / Path(report['inventory']['path']).parent
        bundle.add(run_directory, arcname='static/' + stack + '/' + run_directory.name)
print(json.dumps({'bundle': str(destination), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'light': counters, 'gates': {label: row['exit'] for label, row in receipts.items()}, 'static': {stack: row['exitCode'] for stack, row in adapters.items()}}, indent=2))
