import pathlib, tempfile, subprocess, json, os, stat, sys, hashlib
repo=pathlib.Path.cwd()
root=pathlib.Path(tempfile.mkdtemp(prefix='dyd1029-review-config-'))
log=[]
def run(cwd,*args):
 p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 log.append({'cwd':str(cwd),'argv':args,'exit':p.returncode,'output':p.stdout})
 if p.returncode: raise RuntimeError(p.stdout)
 return p.stdout.strip()
try:
 main=root/'main';main.mkdir();tree=root/'tree'
 run(main,'git','init','-b','main')
 run(main,'git','config','user.name','Review Fixture')
 run(main,'git','config','user.email','review@example.invalid')
 run(main,'git','config','commit.gpgsign','false')
 run(main,'git','config','core.filemode','true')
 (main/'file.txt').write_text('base\n')
 run(main,'git','add','file.txt');run(main,'git','commit','-m','seed')
 (main/'dydo.json').write_text('{"archive":{"reserveBytes":0,"reservePercent":0}}')
 run(main,'git','config','extensions.worktreeConfig','true')
 run(main,'git','worktree','add','-b','topic',str(tree))
 run(tree,'git','config','--worktree','core.filemode','false')
 os.chmod(tree/'file.txt',0o755)
 before=run(tree,'git','status','--porcelain=v1')
 command=['dotnet',str(repo/'bin/Debug/net10.0/dydo.dll'),'archive']
 run(main,*command,'worktree',str(tree))
 entries=[p for p in (main/'.git/dydo/safe-delete-archive').iterdir() if p.is_dir() and not p.name.startswith('.')]
 assert len(entries)==1
 run(main,'git','reflog','expire','--expire=now','--all');run(main,'git','gc','--prune=now')
 run(main,*command,'restore',entries[0].name)
 after=run(tree,'git','status','--porcelain=v1')
 actual=run(tree,'git','config','--get','core.filemode')
 print(json.dumps({'fixture':str(root),'before':before,'after':after,'restored_core_filemode':actual,'archive_and_restore_exit':0}))
 assert before=='' and after=='M file.txt' and actual=='true'
finally:
 (root/'probe.json').write_text(json.dumps({'candidate':run(repo,'git','rev-parse','HEAD'),'source_sha256':hashlib.sha256((repo/'Services/SafeDeleteService.cs').read_bytes()).hexdigest(),'runs':log},indent=2))
 print('Evidence:',root/'probe.json')
