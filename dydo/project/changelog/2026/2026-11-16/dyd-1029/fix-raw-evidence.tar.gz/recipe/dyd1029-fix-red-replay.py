from pathlib import Path
import subprocess

paths = [Path('Services') / name for name in ('SafeDeleteGitHub.cs', 'SafeDeleteService.cs', 'SafeDeleteGit.cs')]
successor = {path: path.read_bytes() for path in paths}
try:
    for path in paths:
        path.write_bytes(subprocess.check_output(['git', 'show', 'ab242bdb33d85c521e5ea1a852de00007bf0ec0d:' + str(path)]))
    result = subprocess.run(['python3', '/tmp/dyd1029-run.py', 'fix-reverted-red', 'probe', 'dotnet', 'test',
        'DynaDocs.Tests/DynaDocs.Tests.csproj', '--filter',
        'FullyQualifiedName~ForkBranchUsedAsUpstreamPullRequestHead|FullyQualifiedName~WorktreeFilemodeOverride|FullyQualifiedName~RestoreWithChangedSharedSettings',
        '--logger', 'trx', '--results-directory', '/tmp/dyd1029-runs/fix-reverted-red/trx'], check=False)
finally:
    for path, contents in successor.items():
        path.write_bytes(contents)
raise SystemExit(result.returncode)
