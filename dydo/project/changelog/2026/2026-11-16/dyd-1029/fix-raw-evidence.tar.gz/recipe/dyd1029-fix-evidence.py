from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path.cwd()
evidence = root / 'dydo/project/changelog/2026/2026-11-16/dyd-1029'
prefix = str(evidence.relative_to(root)) + '/'
owned = set((evidence / 'owned-paths.txt').read_text().splitlines())
changed_paths = subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard'],text=True).splitlines()
unexpected = [name for name in changed_paths if name not in owned and not name.startswith(prefix)]
if unexpected:
    raise SystemExit('Unowned paths: ' + repr(unexpected))
if 'mutation availability and review grading' not in (evidence / 'fix-contract.txt').read_text():
    raise SystemExit('Missing current DECIDED contract snapshot')
paths = []
cutoff = datetime.fromisoformat(json.loads(Path('/tmp/dyd1029-runs/fix-static/receipt.json').read_text())['start']).timestamp()
for run in sorted(Path('/tmp/dyd1029-runs').glob('fix-*')):
    for path in sorted(run.rglob('*')):
        if path.is_file():
            paths.append((path, 'runs/' + str(path.relative_to('/tmp/dyd1029-runs'))))
for name in ['dyd1029-run.py', 'dyd1029-fix-red-replay.py', 'dyd1029-fix-config-probe.py', 'dyd1029-fix-evidence.py', 'dyd1029-fix-validate.py', 'dyd1029-fix-cleanup.py']:
    paths.append((Path('/tmp') / name, 'recipe/' + name))
for name in ['config-probe.py', 'config-probe.json']:
    paths.append((Path('/tmp/dyd1029-codex-review') / name, 'review-original/' + name))
for fixture in ['dyd1029-review-config-hx3jvn2r', 'dyd1029-review-config-j09rc_1y']:
    paths.append((Path('/tmp') / fixture / 'probe.json', 'exact-witness/' + fixture + '.json'))
names = [name.decode() for name in subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z']).split(b'\0') if name]
sources = {name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in names if not name.startswith(prefix) and Path(name).is_file()}
for label in ['fix-light-sequential', 'fix-static', 'fix-coverage']:
    receipt = json.loads((Path('/tmp/dyd1029-runs') / label / 'receipt.json').read_text())
    for name, digest in sources.items():
        if receipt['files'].get(name) != digest:
            raise SystemExit(label + ': source differs: ' + name)
changed = subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
for name in changed:
    if not name.startswith(prefix):
        paths.append((Path(name), 'source/successor/' + name))
        target = Path('/tmp/dyd1029-fix-original') / name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(subprocess.check_output(['git','show','ab242bdb33d85c521e5ea1a852de00007bf0ec0d:' + name]))
        paths.append((target, 'source/original/' + name))
for path in sorted((root / 'DynaDocs.Tests/coverage/results').rglob('*')):
    if path.is_file() and path.stat().st_mtime >= cutoff and path.suffix in {'.json','.xml','.trx','.log','.stdout','.stderr','.sarif','.txt'}:
        paths.append((path,'gates/' + str(path.relative_to(root / 'DynaDocs.Tests/coverage/results'))))
archive = evidence / 'fix-raw-evidence.tar.gz'
digests = {}
first = {}
with tarfile.open(archive,'w:gz') as output:
    for path, name in paths:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        digests[name] = digest
        if digest not in first:
            output.add(path,arcname=name,recursive=False)
            first[digest] = name
        else:
            info = output.gettarinfo(path,arcname=name)
            info.type = tarfile.LNKTYPE
            info.linkname = first[digest]
            info.size = 0
            output.addfile(info)
(evidence / 'fix-raw-evidence-index.json').write_text(json.dumps({'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':digests},indent=2)+'\n')
(evidence / 'fix-source-bytes.json').write_text(json.dumps({'parent':'ab242bdb33d85c521e5ea1a852de00007bf0ec0d','base':'dee4861ae2691e41d9e60985e3e0ffb0c7ea987d','files':sources},indent=2)+'\n')
proof = '''DYD-1029 implementation fix hop; code-writer/model: gpt-6.1-sol high
Parent: ab242bdb33d85c521e5ea1a852de00007bf0ec0d.
Base: dee4861ae2691e41d9e60985e3e0ffb0c7ea987d (ancestor checked before edits).
Initial observed checkout: clean DYD-1029-safe-delete, isolated captain checkout
/home/balazs/.t3/worktrees/DynaDocs/t3-8d7ada1c-88d218c54a54db07, not the main checkout.
All changed production/tests/docs paths are in the retained 60-path ownership manifest;
successor evidence is within its contracted ticket-evidence directory. Original evidence intact.

Closed implementation blocker 1 by fail-closed eligibility. A repository pull list is not
exhaustive cross-repository head evidence, including for forks; search indexing is not used
as authority. Production remote-backed archive/delete now refuses even after empty or valid
nonmatching selected-repository pages. Known protected head/base refusals remain specific.
The realistic regression runs the archive command over a real linked worktree/local bare fork
remote, with an API-process seam returning empty fork pull pages and an upstream PR using that
fork's topic head. It proves the selected remote ref, local ref and unique working file remain
intact, with no archive created. It also validates the upstream response identifies the head.
Product limitation prepared for captain: no general remote eligibility success is claimed;
an exhaustive authoritative future mechanism would be a separate implementation decision.

Closed implementation blocker 2 by installing saved required settings in the fresh independent
proof repository's local config and restored worktree config when extensions.worktreeConfig
is already enabled. Shared/global config is never changed. With worktree config disabled,
matching inherited settings require no writes; differing settings refuse restore and retain
the complete archive. No automatic shared extension migration is attempted.
All captured/proof/restored status commands now use ordinary Git configuration, no -c overrides.
The retained regression sets common core.filemode=true, source worktree core.filemode=false,
chmods file.txt executable while initially clean, archives/deletes, expires reflogs and runs
source gc, then restores: ordinary status is clean, effective source override is false, and
common config is byte-identical. Another regression proves changed shared settings are refused
without rewriting common config. Restore failure may leave newly created refs/registration;
the archive remains complete; no rollback claim is made.

Meaningful RED/fix/revert proof:
- fix-blockers-red: exit 1, both new blockers RED on original implementation. Fork expected
  refusal 2 but got deletion success 0; ordinary restored status expected clean but got M file.txt.
- fix-exact-config-red: reviewer's exact original CLI probe, exit 0 confirming its bug assertion:
  before clean, after M file.txt, effective core.filemode=true. Raw child argv/outputs retained.
- fix-blockers-green and fix-strongest-witness: both blocker regressions pass.
- fix-exact-config-green: same reviewer script with only its outcome assertion corrected;
  archive/GC/restore exit 0, before/after clean, effective core.filemode=false.
- fix-reverted-red: restore only the three implicated implementation files from the parent;
  all THREE regressions RED, exit 1, then exact successor source bytes restored in finally.
- fix-regressions-final: all THREE GREEN after restoration, exit 0.
Both strongest exact witnesses were replayed before expensive broad gates.

Light/static/coverage reach and gates:
Selection retains all SafeDelete unit/integration/generated executable Gherkin tests, reached
Git/clean/guard/init/help/completion/CLI/reference/workflow consumers and their shared tests.
fix-preflight-host pins SDK 10.0.303, runtime 10.0.14 installed, Git 2.53.0, assurance Python
3.14.4 and nonzero regression discovery. fix-light-discovery retains full nonzero selection.
No maintained Python executable changed; only .NET gates apply to this hop. Guard performance
Heavy is dormant and untriggered: no parser/reader architecture or performance behavior changed.
Whole-stack .NET coverage remains required because the facade lacks ticket selection.
fix-light failed exit 1 (9 missing-binary/startup-hook failures): writer incorrectly overlapped
static, whose rebuild removed the binaries used by in-flight child processes. This failed raw
receipt is preserved. The exact unchanged selection was rerun sequentially, not broadened.
Final evidence bytes match the gate receipts for every non-evidence source path.
Sequential Light: 4151 passed, zero failures, 17 platform skips; source-level .NET static
and full Linux-portion .NET coverage gates both exit0. dydo check: zero errors/warnings in
894 files. Native platform skips do not prove Windows coverage or execution.

Exact rerun recipe (extract recipe/dyd1029-run.py to /tmp first; use fresh labels):
python3 /tmp/dyd1029-run.py REPLAY-fix-witness probe dotnet test DynaDocs.Tests/DynaDocs.Tests.csproj --filter 'FullyQualifiedName~ForkBranchUsedAsUpstreamPullRequestHead|FullyQualifiedName~WorktreeFilemodeOverride|FullyQualifiedName~RestoreWithChangedSharedSettings' --logger trx
python3 /tmp/dyd1029-run.py REPLAY-fix-light gate dotnet test DynaDocs.Tests/DynaDocs.Tests.csproj --filter 'FullyQualifiedName~SafeDelete|FullyQualifiedName~Clean|FullyQualifiedName~Git|FullyQualifiedName~Guard|FullyQualifiedName~BashCommandAnalyzer|FullyQualifiedName~DangerousPattern|FullyQualifiedName~InitCommandTests|FullyQualifiedName~Completion|FullyQualifiedName~Help|FullyQualifiedName~CommandSmoke|FullyQualifiedName~CommandDocConsistency|FullyQualifiedName~ReleaseWorkflow' --logger trx
python3 /tmp/dyd1029-run.py REPLAY-fix-static gate .static-gates/python/bin/python DynaDocs.Tests/coverage/gap_check.py gate static --stack dotnet
python3 /tmp/dyd1029-run.py REPLAY-fix-coverage gate .static-gates/python/bin/python DynaDocs.Tests/coverage/gap_check.py gate coverage --stack dotnet
python3 /tmp/dyd1029-run.py REPLAY-fix-mutation gate .static-gates/python/bin/python DynaDocs.Tests/coverage/gap_check.py gate mutation --since dee4861ae2691e41d9e60985e3e0ffb0c7ea987d --stack dotnet
Run these sequentially: static rebuilds local binaries. Exact CLI config witness:
python3 /tmp/dyd1029-run.py REPLAY-fix-config probe python3 /tmp/dyd1029-fix-config-probe.py
Revert recipe/dyd1029-fix-red-replay.py is pinned to parent and mutates only the three owned
implementation files inside try/finally; its RED receipt pins actual tested original bytes.
The shared /var/tmp/dydo-gate-lock.sh stays outside systemd scope. Probes: MemoryMax=4G,
MemorySwapMax=0, OOMPolicy=continue, timeout120. Gates: 8G, swap0, continue, timeout3600.
Nearest agent slice app-t3code-agents-cbc6c2286251.slice. Environment for .NET:
MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_USE_MSBUILD_SERVER=0 UseSharedCompilation=false.
Sandbox user-bus denial is retained (fix-preflight); successful runs used escalation of the
capped wrapper, never an uncapped retry. The only concurrency was two gate operations;
no crew or subagents were started; no candidate-branch push, PR or ticket status change was made.

Governing reconciliation and outstanding captain proof:
See fix-contract.txt: exact live Linear description, updatedAt 2026-11-16T23:50:22.766Z,
including the DECIDED admiral ruling. The original contract.txt remains unchanged.
fix-review-blocks.txt and fix-linear-snapshot.json retain the original Claude PASS, Codex FAIL,
merged first-round FAIL disposition, mutation ruling, captain disposition and native T3 report.
Historical reviewer claims remain verbatim and are qualified by the merged disposition.
Deferred shoulds DYD-1133/1134/1135 block landing DYD-1076; five parent nits remain out of this hop.
Mutation is exit 2 fail-closed UNAVAILABLE, inherited owner DYD-103, never PASS, and under
that ruling does not hold offer. Meaningful RED and fresh cross-vendor review remain required.
Round 2+ grading follows DR 058: wrong intended behavior blocker; correct behavior/test-only
gap should. This writer changes no acceptance criteria and claims no mutation assurance.
Native Windows execution/coverage remains owed to captain and has not passed in this hop.
No Linux skip/early return is Windows evidence. Fresh independent cross-vendor review and
captain's rerun of the actual proof recipe remain owed.

T3 evidence supplied by captain, not executed by this fix writer:
native-t3-67a2060b-evidence.tar.gz is copied byte-identically from the supplied portable archive;
SHA256 90552ab159f0bdcbcaef4495ac7c7c1b8f2536c352c655744db1d6ba15336bb2.
native-t3-67a2060b-README.txt is the verbatim supplied README.md (also inside archive).
It applies ONLY to original ab242bdb33d85c521e5ea1a852de00007bf0ec0d: protective native CLI
exit2 before network/archive access, all 2478 tracked paths/index/ref/registration/sentinel
retained, subsequent live retained-target list/read health. Generated build artifacts are
excluded. No deletion, archive/restore, inactive release or stale-missing-thread health proof
is claimed. T3_RELEASE_UNPROVEN and production refusal remain unchanged; captain will replay
relevant proof on successor. This evidence is not silently upgraded to successor proof.

Observed run receipts (each contains exact argv, environment prefix, cap, dirty bytes, exit,
timestamps and raw-log path inside fix-raw-evidence.tar.gz):
'''
for run in sorted(Path('/tmp/dyd1029-runs').glob('fix-*')):
    receipt = json.loads((run / 'receipt.json').read_text())
    proof += f"{run.name}: exit={receipt.get('exit')}; start={receipt['start']}; end={receipt.get('end')}; runs/{run.name}/raw.log\n"
    proof += '  argv=' + json.dumps(receipt['argv']) + '\n'
    for trx in sorted(run.rglob('*.trx')):
        counters = ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters')
        if counters is not None:
            proof += '  TRX counters=' + json.dumps(counters.attrib,sort_keys=True) + '\n'
(evidence / 'fix-proof.txt').write_text(proof)
owned_successor = sorted(set(subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard'],text=True).splitlines()) | {prefix + 'fix-owned-paths.txt', prefix + 'fix-cleanup.json'})
(evidence / 'fix-owned-paths.txt').write_text('\n'.join(owned_successor)+'\n')
print(archive,archive.stat().st_size,'bytes;',len(paths),'raw files;',len(sources),'source hashes')
