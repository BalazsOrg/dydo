from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import xml.etree.ElementTree as ET

evidence = Path('dydo/project/changelog/2026/2026-11-16/dyd-1029')
index = json.loads((evidence / 'fix-raw-evidence-index.json').read_text())
archive = evidence / 'fix-raw-evidence.tar.gz'
assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest() == index['archiveSha256']
with tarfile.open(archive) as bundle:
    for name, digest in index['files'].items():
        assert hashlib.file_digest(bundle.extractfile(name),'sha256').hexdigest() == digest, name
source = json.loads((evidence / 'fix-source-bytes.json').read_text())
for name, digest in source['files'].items():
    assert hashlib.file_digest(Path(name).open('rb'),'sha256').hexdigest() == digest, name
original_evidence = [p for p in subprocess.check_output(['git','ls-tree','-r','--name-only','ab242bdb','--',str(evidence)],text=True).splitlines()]
assert subprocess.check_output(['git','diff','--name-only','ab242bdb','--',*original_evidence],text=True) == ''
for label in ['fix-regressions-final','fix-light-sequential','fix-static','fix-coverage']:
    receipt = json.loads((Path('/tmp/dyd1029-runs') / label / 'receipt.json').read_text())
    assert receipt['exit'] == 0, label
assert json.loads(Path('/tmp/dyd1029-runs/fix-mutation/receipt.json').read_text())['exit'] == 2
trx = next(Path('/tmp/dyd1029-runs/fix-light-sequential/trx').glob('*.trx'))
results = ET.parse(trx).findall('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}UnitTestResult')
safe = [r for r in results if 'SafeDelete' in r.attrib['testName']]
assert safe and all(r.attrib['outcome'] == 'Passed' for r in safe)
native = evidence / 'native-t3-67a2060b-evidence.tar.gz'
assert hashlib.file_digest(native.open('rb'),'sha256').hexdigest() == '90552ab159f0bdcbcaef4495ac7c7c1b8f2536c352c655744db1d6ba15336bb2'
with tarfile.open(native) as bundle:
    assert bundle.extractfile('./README.md').read() == (evidence / 'native-t3-67a2060b-README.txt').read_bytes()
    assert not any('/artifacts/' in m.name or m.name.endswith(('.dll','.pdb')) for m in bundle.getmembers())
print(json.dumps({'verifiedRawMembers':len(index['files']),'verifiedSourceHashes':len(source['files']),
    'originalEvidenceUnchanged':len(original_evidence),'safeDeletePassed':len(safe),
    'nativeArchiveByteIdentical':True,'nativeSourceCandidate':'ab242bdb33d85c521e5ea1a852de00007bf0ec0d'},indent=2))
