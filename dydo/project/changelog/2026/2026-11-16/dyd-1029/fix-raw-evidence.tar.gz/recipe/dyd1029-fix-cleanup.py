from pathlib import Path
import hashlib
import json
import shutil

evidence = Path('dydo/project/changelog/2026/2026-11-16/dyd-1029')
archive = evidence / 'fix-raw-evidence.tar.gz'
assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest() == json.loads((evidence / 'fix-raw-evidence-index.json').read_text())['archiveSha256']
removed = []
for name in ('dyd1029-review-config-hx3jvn2r', 'dyd1029-review-config-j09rc_1y'):
    fixture = Path('/tmp') / name
    assert fixture.parent == Path('/tmp') and not fixture.is_symlink()
    assert (fixture / 'probe.json').is_file() and (fixture / 'main/.git').is_dir()
    shutil.rmtree(fixture)
    assert not fixture.exists()
    removed.append(str(fixture))
(evidence / 'fix-cleanup.json').write_text(json.dumps({'ownedExactWitnessFixturesRemoved':removed,'rawEvidenceRetained':str(archive)},indent=2)+'\n')
print('Removed only the two exact CLI witness fixtures; raw receipts retained in the verified archive.')
