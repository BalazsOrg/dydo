set -eu
dotnet --version
dotnet --list-runtimes
git --version
.static-gates/python/bin/python --version
gh --version
