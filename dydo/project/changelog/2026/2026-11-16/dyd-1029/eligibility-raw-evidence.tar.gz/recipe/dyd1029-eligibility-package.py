from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path.cwd()
out = root / "dydo/project/changelog/2026/2026-11-16/dyd-1029"
parent = "785971749b44c2f7147e6250683a5b2ac43cf1e3"
prefix = str(out.relative_to(root)) + "/"
owned = {
    "DynaDocs.Tests/Features/safe-delete.feature",
    "DynaDocs.Tests/Integration/SafeDeleteGitHubTests.cs",
    "DynaDocs.Tests/Integration/SafeDeletePolicyTests.cs",
    "DynaDocs.Tests/Integration/SafeDeleteTests.cs",
    "DynaDocs.Tests/Steps/SafeDeleteSteps.cs",
    "DynaDocs.Tests/coverage/test-associations.json",
    "Models/SafeDeleteManifest.cs",
    "Scaffold/dydo/reference/dydo-commands.md",
    "Services/SafeDeleteDependencies.cs",
    "Services/SafeDeleteGitHub.cs",
    "Services/SafeDeleteGitHubTarget.cs",
    "Services/SafeDeleteService.cs",
    "dydo/reference/dydo-commands.md",
}
def git(*args):
    return subprocess.check_output(["git",*args])

assert git("rev-parse","HEAD").decode().strip() == parent
assert git("branch","--show-current").decode().strip() == "DYD-1029-safe-delete"
assert git("rev-parse","--show-toplevel").decode().strip() == str(root)
subprocess.run(["git","merge-base","--is-ancestor","dee4861ae2691e41d9e60985e3e0ffb0c7ea987d","HEAD"],check=True)
changed = set(git("diff","--name-only",parent).decode().splitlines())
changed.update(git("ls-files","--others","--exclude-standard").decode().splitlines())
assert all(p in owned or p.startswith(prefix + "eligibility-") for p in changed), changed
original_evidence = {}
for name in git("ls-tree","-r","--name-only",parent,"--",str(out.relative_to(root))).decode().splitlines():
    old = git("show",parent + ":" + name)
    assert (root/name).read_bytes() == old, name
    original_evidence[name] = hashlib.sha256(old).hexdigest()

service = (root/"Services/SafeDeleteService.cs").read_text()
old_service = git("show",parent + ":Services/SafeDeleteService.cs").decode()
start = "    private static void Reconstruct("
end = "    private static void Recheck("
saved_config = service[service.index(start):service.index("    private void RecheckRemote(")]
assert saved_config == old_service[old_service.index(start):old_service.index(end)]
for name in ("Git","Repository","History","Files","Store","T3Policy","Paths"):
    path = "Services/SafeDelete" + name + ".cs"
    assert (root/path).read_bytes() == git("show",parent + ":" + path)

sources = {}
for raw in git("ls-files","-c","-o","--exclude-standard","-z").split(b"\0"):
    if not raw: continue
    name = raw.decode()
    if name.startswith(prefix): continue
    path = root/name
    if path.is_file() and not path.is_symlink():
        sources[name] = hashlib.sha256(path.read_bytes()).hexdigest()
(out/"eligibility-source-bytes.json").write_text(json.dumps(sources,indent=2,sort_keys=True)+"\n")
(out/"eligibility-owned-paths.txt").write_text("\n".join(sorted(changed))+"\n")

runs = []
artifacts = {}
def add(path, name):
    path = Path(path)
    if path.is_file() and not path.is_symlink(): artifacts[name] = path

for run in sorted(Path("/tmp/dyd1029-runs").glob("eligibility-*")):
    receipt_path = run/"receipt.json"
    if not receipt_path.exists(): continue
    receipt = json.loads(receipt_path.read_text())
    if "exit" not in receipt: continue
    summary = {k:receipt[k] for k in ("head","start","end","exit","argv","status")}
    summary["label"] = run.name
    summary["receipt"] = "runs/" + run.name + "/receipt.json"
    summary["sourceFiles"] = len(receipt["files"])
    summary["trx"] = []
    for trx in run.rglob("*.trx"):
        document = ET.parse(trx)
        ns = {"t":"http://microsoft.com/schemas/VisualStudio/TeamTest/2010"}
        counters = document.find(".//t:Counters",ns)
        definitions = {t.attrib["id"]:t.find("t:TestMethod",ns).attrib["className"]
                       for t in document.findall(".//t:UnitTest",ns)}
        safe = [t for t in document.findall(".//t:UnitTestResult",ns)
                if "SafeDelete" in definitions.get(t.attrib["testId"],"")]
        summary["trx"].append({"path":str(trx.relative_to(run)),
                               "counters":counters.attrib,
                               "safeDeleteResults":len(safe),
                               "safeDeleteOutcomes":{s:sum(t.attrib["outcome"]==s for t in safe) for s in {t.attrib["outcome"] for t in safe}}})
    runs.append(summary)
    for path in run.rglob("*"):
        add(path,"runs/" + str(path.relative_to(run.parent)))
    log = (run/"raw.log").read_text()
    for result in re.findall(r"Result: (\S+)",log):
        result_path = Path(result)
        if result_path.is_file():
            for path in result_path.parent.rglob("*"):
                add(path,"facade/" + result_path.parent.name + "/" + str(path.relative_to(result_path.parent)))

for name in ("dotnet-static.json","dotnet-coverage.json","dotnet-mutation.json"):
    adapter = root/"DynaDocs.Tests/coverage/results/adapters"/name
    add(adapter,"facade/adapters/" + name)
    if adapter.is_file():
        report = json.loads(adapter.read_text())
        inventory = report.get("inventory",{}).get("path")
        if inventory:
            run_directory = (root/"DynaDocs.Tests/coverage/results"/inventory).parent
            assert run_directory.is_relative_to(root/"DynaDocs.Tests/coverage/results/assurance")
            for path in run_directory.rglob("*"):
                add(path,"facade/assurance/" + run_directory.name + "/" + str(path.relative_to(run_directory)))
for path in Path("/tmp/dyd1029-eligibility-artifacts").rglob("*"):
    add(path,"facade/retained/" + str(path.relative_to("/tmp/dyd1029-eligibility-artifacts")))
    if path.name == "dotnet-static.json":
        inventory = json.loads(path.read_text())["inventory"]["path"]
        run_directory = (root/"DynaDocs.Tests/coverage/results"/inventory).parent
        for raw in run_directory.rglob("*"):
            add(raw,"facade/assurance/" + run_directory.name + "/" + str(raw.relative_to(run_directory)))
native_backup = Path("/tmp/dyd1029-eligibility-artifacts/native-config/probe.json")
if not native_backup.exists():
    native_backup.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(out/"eligibility-raw-evidence.tar.gz","r:gz") as previous:
        native_backup.write_bytes(previous.extractfile("native-config/probe.json").read())
for path in Path("/tmp/dyd1029-review-config-esx_00aj").glob("probe.json"):
    add(path,"native-config/" + path.name)
add(native_backup,"native-config/probe.json")
for name in ("dyd1029-run.py","dyd1029-eligibility-red-replay.py","dyd1029-eligibility-toolchain.sh","dyd1029-fix-config-probe.py","dyd1029-eligibility-package.py"):
    add(Path("/tmp")/name,"recipe/" + name)

summary = {
    "parent":parent,"model":"code-writer/gpt-6.1-sol high","ownedNonEvidence":sorted(owned),
    "sourceFileCount":len(sources),"sourceMapSha256":hashlib.sha256((out/"eligibility-source-bytes.json").read_bytes()).hexdigest(),
    "originalEvidenceUnchanged":original_evidence,
    "restoreConfigAndReconstructionBytesUnchangedSha256":hashlib.sha256(saved_config.encode()).hexdigest(),
    "runs":runs,
}
(out/"eligibility-run-summary.json").write_text(json.dumps(summary,indent=2)+"\n")
with tarfile.open(out/"eligibility-raw-evidence.tar.gz","w:gz") as archive:
    index = {}
    for name,path in sorted(artifacts.items()):
        content = path.read_bytes()
        assert not re.search(rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|Authorization: (?:token|bearer) [A-Za-z0-9_]{20,})",content), name
        archive.add(path,arcname=name,recursive=False)
        index[name] = {"bytes":len(content),"sha256":hashlib.sha256(content).hexdigest()}
(out/"eligibility-raw-evidence-index.json").write_text(json.dumps(index,indent=2)+"\n")
config_fixture = Path("/tmp/dyd1029-review-config-esx_00aj")
assert config_fixture.name == "dyd1029-review-config-esx_00aj" and config_fixture.parent == Path("/tmp")
assert "native-config/probe.json" in index
if config_fixture.exists(): shutil.rmtree(config_fixture)
assert not config_fixture.exists()
print(json.dumps({"sourceFiles":len(sources),"retainedArtifacts":len(artifacts),"originalEvidenceUnchanged":len(original_evidence),"evidenceBytes":(out/"eligibility-raw-evidence.tar.gz").stat().st_size,"runs":[{"label":r["label"],"exit":r["exit"],"trx":r["trx"]} for r in runs]},indent=2))
