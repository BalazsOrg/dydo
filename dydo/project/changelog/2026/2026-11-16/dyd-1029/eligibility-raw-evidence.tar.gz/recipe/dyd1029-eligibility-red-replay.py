from pathlib import Path
import hashlib
import subprocess

path = Path("Services/SafeDeleteGitHub.cs")
successor = path.read_bytes()
needle = b"target.Metadata = identity;\n            return null;"
assert successor.count(needle) == 1
# Revert the root availability correction to the predecessor's blanket refusal,
# preserving the new typed/API seam so these exact successor tests still execute.
reverted = successor.replace(needle, b'target.Metadata = identity;\n            return "cross-repository PR head eligibility is unproven; local target retained";')
try:
    path.write_bytes(reverted)
    print("Successor GitHub SHA256", hashlib.sha256(successor).hexdigest(), flush=True)
    print("Reverted blanket-refusal SHA256", hashlib.sha256(reverted).hexdigest(), flush=True)
    result = subprocess.run([
        "python3", "/tmp/dyd1029-run.py", "eligibility-reverted-red", "probe",
        "dotnet", "test", "DynaDocs.Tests/DynaDocs.Tests.csproj", "--filter",
        "FullyQualifiedName~PublicExactRefWithoutHeadsOrBases|FullyQualifiedName~PrivateClosedWorld_RealCli|FullyQualifiedName~PublicFork_Leased",
        "--logger", "trx", "--results-directory", "/tmp/dyd1029-runs/eligibility-reverted-red/trx"
    ], check=False)
finally:
    path.write_bytes(successor)
    assert path.read_bytes() == successor
raise SystemExit(result.returncode)
