import os, sys, json, subprocess, pathlib, datetime, shlex
ROOT = pathlib.Path(__file__).parent
phase = sys.argv[1]
gate = phase == 'build'
env = os.environ.copy()
env.update(MSBUILDDISABLENODEREUSE='1', DOTNET_CLI_USE_MSBUILD_SERVER='0', UseSharedCompilation='false')
command = ['systemd-run', '--user', '--scope', '--slice=app-t3code-agents-cbc6c2286251.slice', '-p', 'MemoryMax=' + ('8G' if gate else '4G'), '-p', 'MemorySwapMax=0', '-p', 'OOMPolicy=continue', 'timeout', '3600' if gate else '120', 'python3', str(ROOT / 'probe.py'), phase]
command.insert(0, '/var/tmp/dydo-gate-lock.sh')
receipt = dict(argv=command, shell=shlex.join(command), cwd='/tmp', environment={k:env[k] for k in ['MSBUILDDISABLENODEREUSE','DOTNET_CLI_USE_MSBUILD_SERVER','UseSharedCompilation']}, started=datetime.datetime.now(datetime.timezone.utc).isoformat())
(ROOT / (phase + '.command.json')).write_text(json.dumps(receipt, indent=2))
with (ROOT / (phase + '.stdout')).open('wb') as stdout, (ROOT / (phase + '.stderr')).open('wb') as stderr:
    result = subprocess.run(command, cwd='/tmp', env=env, stdout=stdout, stderr=stderr)
receipt.update(exit=result.returncode, completed=datetime.datetime.now(datetime.timezone.utc).isoformat())
(ROOT / (phase + '.result.json')).write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
print((ROOT / (phase + '.stdout')).read_text()[-4000:])
print((ROOT / (phase + '.stderr')).read_text()[-2000:])
sys.exit(result.returncode)
