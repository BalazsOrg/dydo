import os, sys, json, pathlib, subprocess, hashlib, stat, datetime, shutil
ROOT = pathlib.Path(__file__).parent
TARGET = pathlib.Path('/home/balazs/.t3/worktrees/DynaDocs/t3-c0bbb510-5de29838258bd706')
EXPECTED = 'ab242bdb33d85c521e5ea1a852de00007bf0ec0d'
BRANCH = 'refs/heads/t3/prove-native-t3-refusal'
SENTINEL = TARGET / '.dyd1029-native-t3-67a2060b.sentinel'
SENTINEL_BYTES = b'DYD-1029 owned native refusal sentinel 67a2060b\x00\xff\n'
CONTEXT = ROOT / 'repository-context'

def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')

def run(name, argv, cwd=TARGET, check=True):
    result = subprocess.run([str(x) for x in argv], cwd=cwd, capture_output=True)
    (ROOT / (name + '.stdout')).write_bytes(result.stdout)
    (ROOT / (name + '.stderr')).write_bytes(result.stderr)
    write(name + '.result.json', dict(argv=[str(x) for x in argv], cwd=str(cwd), exit=result.returncode))
    if check and result.returncode:
        raise RuntimeError(f'{name} failed: {result.returncode}: {result.stderr.decode(errors="replace")}')
    return result

def git(name, *argv, cwd=TARGET):
    return run(name, ['git', '--no-optional-locks', *argv], cwd).stdout

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def entry(path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return dict(kind='absent')
    result = dict(mode=stat.S_IMODE(st.st_mode), size=st.st_size)
    if stat.S_ISLNK(st.st_mode):
        result.update(kind='link', target=os.readlink(path))
    elif stat.S_ISREG(st.st_mode):
        result.update(kind='file', sha256=digest(path))
    elif stat.S_ISDIR(st.st_mode):
        result.update(kind='directory')
    else:
        result.update(kind='special')
    return result

def common():
    return pathlib.Path(git('common-' + sys.argv[1], 'rev-parse', '--path-format=absolute', '--git-common-dir').decode().strip())

def snapshot(phase):
    names = git(phase + '-ls-files', 'ls-files', '-z').split(b'\0')
    files = {os.fsdecode(n):entry(TARGET / os.fsdecode(n)) for n in names if n}
    head = git(phase + '-head', 'rev-parse', 'HEAD').decode().strip()
    oid = git(phase + '-branch-oid', 'rev-parse', '--verify', BRANCH).decode().strip()
    trees = git(phase + '-git-worktree-list', 'worktree', 'list', '--porcelain', '-z')
    blocks = [b for b in trees.split(b'\0\0') if b.startswith(b'worktree ' + os.fsencode(TARGET) + b'\0')]
    assert len(blocks) == 1, 'exact fixture must remain registered'
    gitdir = pathlib.Path(git(phase + '-gitdir', 'rev-parse', '--absolute-git-dir').decode().strip())
    archive = common() / 'dydo' / 'safe-delete-archive'
    archive_children = sorted(p.name for p in archive.iterdir()) if archive.exists() else None
    result = dict(head=head, branch_oid=oid, registered_target=blocks[0].decode(), tracked_files=files,
                  sentinel=entry(SENTINEL), gitfile=entry(TARGET / '.git'), index=entry(gitdir/'index'),
                  head_metadata=entry(gitdir/'HEAD'), archive_root=str(archive), archive_children=archive_children)
    write(phase + '-snapshot.json', result)
    return result

phase = sys.argv[1]
cgroup = pathlib.Path('/proc/self/cgroup').read_text()
path = pathlib.Path('/sys/fs/cgroup') / cgroup.strip().split('::', 1)[1].lstrip('/')
limits = {key:(path/key).read_text().strip() for key in ['memory.max','memory.swap.max']}
write(phase + '-containment.json', dict(cgroup=cgroup, limits=limits, cwd=os.getcwd(), pid=os.getpid()))
assert limits['memory.max'] == str((8 if phase == 'build' else 4)*1024**3), limits
assert limits['memory.swap.max'] == '0', limits

if phase == 'inspect':
    assert TARGET.resolve() == TARGET and TARGET.is_dir()
    assert git('source-sha', 'rev-parse', 'HEAD').decode().strip() == EXPECTED
    assert git('initial-status', 'status', '--porcelain=v1') == b'', 'fixture must start clean'
    run('dotnet-info', ['dotnet', '--info'])
    for name in ['Services/SafeDeleteT3Policy.cs','Services/SafeDeleteRepository.cs','Services/SafeDeleteService.cs','Services/SafeDeleteDependencies.cs','Services/GitRunner.cs','Commands/ArchiveCommand.cs','Program.cs','DynaDocs.csproj',
                 'dydo/project/changelog/2026/2026-11-16/dyd-1029/contract.txt','dydo/project/changelog/2026/2026-11-16/dyd-1029/t3-source-evidence.txt','dydo/project/changelog/2026/2026-11-16/dyd-1029/t3-settings-evidence.txt']:
        dest = ROOT / 'source' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(TARGET / name, dest)
    tracked = git('identity-ls-files', 'ls-files', '-z').split(b'\0')
    hashes = {os.fsdecode(n): entry(TARGET/os.fsdecode(n)) for n in tracked if n}
    write('source-identity.json', dict(sha=EXPECTED, branch=BRANCH, tracked=hashes))
    CONTEXT.mkdir()
    # An owned, unregistered Git discovery context under /tmp. Only this gitfile is
    # created; the existing common repository and fixture administration are read.
    (CONTEXT / '.git').write_text('gitdir: ' + str(common()) + '\n')
    assert git('context-common', 'rev-parse', '--path-format=absolute', '--git-common-dir', cwd=CONTEXT) == git('fixture-common', 'rev-parse', '--path-format=absolute', '--git-common-dir')
    write('context.json', dict(cwd=str(CONTEXT), gitfile=(CONTEXT/'.git').read_text(), registered=False, policy_injection=False, git_environment_override=False))
    print('Source SHA and clean state match. Context created under /tmp without registering any worktree or changing any ref.')
elif phase == 'build':
    argv = ['dotnet','build',str(TARGET/'DynaDocs.csproj'),'-c','Release','--artifacts-path',str(ROOT/'artifacts'),'-p:PublishAot=false','-p:UseSharedCompilation=false','-nodeReuse:false']
    run('candidate-build', argv)
    dll = ROOT/'artifacts/bin/DynaDocs/release/dydo.dll'
    assert dll.is_file()
    version = run('candidate-version', ['dotnet', dll, '--version'], cwd=CONTEXT)
    write('candidate.json', dict(source_sha=EXPECTED, dll=str(dll), sha256=digest(dll), version=version.stdout.decode().strip(), outputs={str(p.relative_to(ROOT)):digest(p) for p in dll.parent.iterdir() if p.is_file()}))
    assert git('post-build-tracked-status', 'status', '--porcelain=v1', '--untracked-files=no') == b''
    print('Candidate built:', dll, digest(dll))
elif phase == 'before':
    assert not SENTINEL.exists()
    with SENTINEL.open('xb') as out:
        out.write(SENTINEL_BYTES)
    assert git('sentinel-untracked', 'ls-files','--others','--exclude-standard','--',str(SENTINEL)).decode().strip() == SENTINEL.name
    before = snapshot('before')
    assert before['head'] == EXPECTED and before['branch_oid'] == EXPECTED
    print('Before snapshot:', len(before['tracked_files']), 'tracked paths; owned untracked sentinel captured; target registered.')
elif phase == 'invoke':
    candidate = json.loads((ROOT/'candidate.json').read_text())
    dll = pathlib.Path(candidate['dll'])
    assert digest(dll) == candidate['sha256']
    assert SENTINEL.read_bytes() == SENTINEL_BYTES
    assert os.path.commonpath([str(CONTEXT),str(TARGET)]) != str(TARGET)
    argv = ['strace','-f','-qq','-s','4096','-e','trace=%process,%file,%network','-o',str(ROOT/'native.strace'),'dotnet',str(dll),'archive','worktree',str(TARGET)]
    native = run('native-refusal', argv, cwd=CONTEXT, check=False)
    output = native.stdout.decode(errors='replace') + native.stderr.decode(errors='replace')
    expected = 'T3 ownership/activity unavailable: no supported release route with all sharing threads, provider sessions, terminals and workspace lease has passed native disposable-host proof; target retained'
    assert native.returncode == 2 and expected in output, (native.returncode, output)
    trace = (ROOT/'native.strace').read_text()
    processes = [line for line in trace.splitlines() if 'execve(' in line or 'execveat(' in line]
    (ROOT/'native-executed-processes.txt').write_text('\n'.join(processes)+'\n')
    assert not any('"'+word+'"' in line for line in processes for word in ['ls-remote','fetch','push','update-ref','bundle','clone','gh','remove','lock'])
    assert not any('connect(' in line and ('AF_INET' in line or 'sin_port=' in line) for line in trace.splitlines())
    write('native-assertions.json', dict(exit=native.returncode, native_T3_refusal=True, policy_injection=False, environment_bypass=False,
         cwd=str(CONTEXT), exact_target=str(TARGET), no_remote_network_lookup_fetch_or_destructive_git_process=True,
         execve_attempt_count=len(processes), local_remote_selection_precedes_T3_refusal=True))
    print(output.strip())
    print('Native exit 2; process trace has no network remote lookup, fetch or destructive Git command.')
elif phase == 'after':
    before = json.loads((ROOT/'before-snapshot.json').read_text())
    after = snapshot('after')
    assert before == after, 'Before/after snapshots differ; inspect evidence'
    assert SENTINEL.read_bytes() == SENTINEL_BYTES
    write('filesystem-assertions.json', dict(all_equal=True, tracked_paths=len(after['tracked_files']),branch_oid=after['branch_oid'],head=after['head'],target_registered=True,sentinel_unchanged=True,index_unchanged=True,gitfile_unchanged=True,no_archive_entry_created=True))
    print('PASS: tracked paths, branch OID, HEAD/index/gitfile, registration, sentinel and archive directory listing unchanged.')
elif phase == 'cleanup':
    assert json.loads((ROOT/'filesystem-assertions.json').read_text())['all_equal']
    assert SENTINEL.read_bytes() == SENTINEL_BYTES
    SENTINEL.unlink()
    assert not SENTINEL.exists() and TARGET.is_dir()
    assert git('final-status','status','--porcelain=v1') == b''
    assert git('final-head','rev-parse','HEAD').decode().strip() == EXPECTED
    write('cleanup.json', dict(removed_only=str(SENTINEL), target_preserved=str(TARGET), final_clean=True,sha=EXPECTED))
    print('Removed only the owned sentinel; T3 checkout remains intact and clean.')
elif phase == 'audit':
    trace = (ROOT/'native.strace').read_text()
    # strace interleaves execve(... <unfinished ...> with resumed completion lines.
    # Include every attempted exec, so a split successful Git exec cannot be missed.
    process_lines = [line for line in trace.splitlines() if 'execve(' in line or 'execveat(' in line]
    processes = '\n'.join(process_lines) + '\n'
    (ROOT/'native-executed-processes.txt').write_text(processes)
    assert any('"git"' in line and '"worktree", "list"' in line for line in process_lines)
    assert not any('"'+word+'"' in line for line in process_lines for word in ['ls-remote','fetch','push','update-ref','bundle','clone','gh','remove','lock'])
    assertions = json.loads((ROOT/'native-assertions.json').read_text())
    assertions.pop('successful_execve_count', None)
    assertions['execve_attempt_count'] = len(process_lines)
    assertions['interleaved_execve_lines_included'] = True
    write('native-assertions.json', assertions)
    archive = json.loads((ROOT/'before-snapshot.json').read_text())['archive_root']
    assert archive not in trace, 'archive root was unexpectedly accessed'
    assert 'SafeDeleteFakeT3Policy' not in processes
    assert not SENTINEL.exists() and TARGET.is_dir()
    assert json.loads((ROOT/'t3-after.json').read_text())['healthPassed']
    lists = json.loads((ROOT/'t3-worktree-list-after.json').read_text())['result']
    assert lists['isRepo'] and any(t['worktreePath'] == str(TARGET) and t['name'] == BRANCH.removeprefix('refs/heads/') for t in lists['refs'])
    write('audit.json', dict(archive_root_not_accessed=True, literal_cli_cwd=str(CONTEXT), launcher_cwd='/tmp',
        T3CODE_HOME_inherited=os.environ.get('T3CODE_HOME'), introduced_policy_or_git_environment_variables=[],
        native_refusal_and_retained_target_health='PASS', t3_worktree_list_healthy=True,
        limitations=['No inactive T3 deletion proven','No archive/restore of a T3 target proven','No stale-missing-thread health proven','No supported release path enabled','Thread list filtered to owned child; no exhaustive ownership census performed or needed for this unconditional refusal'],
        bootstrap_note='Initial read-only file discovery/cgroup/skill reads ran before containment setup; all candidate build, sentinel, native invocation and state/health filesystem evidence phases were capped. Sandbox user-bus refusal was retried with escalation, never by running the candidate uncapped.'))
    lines = processes.splitlines()
    print('Native exec attempts (including interleaved calls):', len(lines))
    print(processes)
    print('PASS: archive root never accessed; T3 worktree list remains healthy; checkout intact; sentinel absent.')
else:
    raise RuntimeError(phase)
