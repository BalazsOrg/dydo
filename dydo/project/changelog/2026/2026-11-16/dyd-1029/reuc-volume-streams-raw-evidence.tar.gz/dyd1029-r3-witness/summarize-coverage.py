import json, sys
data = json.load(open(sys.argv[1]))
def walk(value, path=''):
    if isinstance(value, dict):
        for key, child in value.items():
            here = f'{path}.{key}'
            if key == 'findings' and isinstance(child, list): print('FINDINGS', here, len(child))
            elif key in ('fingerprint', 'sourceFingerprint') or 'test' in key.lower() and not isinstance(child, (dict, list)): print(here, child)
            else: walk(child, here)
    elif isinstance(value, list):
        for index, child in enumerate(value[:3]): walk(child, f'{path}[{index}]')
print('TOP', list(data))
walk(data)
