import os
import sys
if os.environ.get("DYDO_PYTHON_COVERAGE_CONFIG"):
    try:
        from python_coverage import startup_from_environment
    except BaseException as error:
        try:
            print(f"Python measurement failed in process {os.getpid()} at startup ({sys.orig_argv}): "
                  f"{type(error).__name__}: {error}; it could not be recorded: python_coverage did not import",
                  file=sys.stderr, flush=True)
        finally:
            os._exit(70)
    startup_from_environment()
