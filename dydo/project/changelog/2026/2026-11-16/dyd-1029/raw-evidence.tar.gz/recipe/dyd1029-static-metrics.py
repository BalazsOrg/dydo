import json
import sys

def walk(value):
    if isinstance(value,dict):
        if 'cognitive' in value and 'SafeDelete' in str(value.get('id','')):
            print(json.dumps({key:value[key] for key in ('id','cognitive','cc') if key in value}))
        for child in value.values(): walk(child)
    elif isinstance(value,list):
        for child in value: walk(child)
walk(json.load(open(sys.argv[1])))
