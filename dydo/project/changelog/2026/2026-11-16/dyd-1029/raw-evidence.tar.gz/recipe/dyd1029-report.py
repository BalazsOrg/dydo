from pathlib import Path
import json
import sys
for argument in sys.argv[1:]:
    data = json.loads(Path(argument).read_text())
    print(argument, data.get('verdict',data.get('state')))
    for key, collector in data.get('collectors',{}).items():
        for kind in ('findings','errors'):
            items = collector.get(kind,[])
            if items:
                print(key,kind,len(items))
                for item in items[:35]: print(json.dumps(item)[:2000])
