from pathlib import Path
import json
import hashlib

root = Path.cwd()
evidence = root / 'dydo/project/changelog/2026/2026-11-16/dyd-1029'
runs = Path('/tmp/dyd1029-runs')
receipts = []
for path in runs.glob('*/receipt.json'):
    receipts.append((json.loads(path.read_text()),path.parent.name))
receipts.sort(key=lambda pair:pair[0]['start'])
lines = ['DYD-1029 implementation evidence',
    'code-writer/model: gpt-6.1-sol, high; one author, no child agents.',
    'Branch: DYD-1029-safe-delete; commissioned base: dee4861ae2691e41d9e60985e3e0ffb0c7ea987d.',
    'The candidate commit is the commit containing this evidence. final-source-bytes.json pins all non-evidence bytes; each run receipt pins its observed HEAD, dirty status and file hashes.',
    'Evidence packaging is the only change after final collection. No production target was archived or deleted by this work; destructive journeys own disposable local Git/bare-remote fixtures.',
    '', 'Behavior',
    'Archive branch/worktree/list/restore; controlled same-name fetch and leases; self-contained commit/index-object preservation; ignored files, links and modes; fresh independent reconstruction before publication/deletion; stable recovery refs; create-only restore; reserve/retention policy; guard, init, help, completion, config and reference integration.',
    '', 'RED and successor proof',
    'boundary-red: root-permission change was not refused (expected 2, actual 0); fixed with root metadata rechecks.',
    'feature-red: compile-only failed attempt is retained, not counted as feature RED.',
    'feature-red-02: service implementation removed, tests retained: 66 failed / 65 passed / 0 skipped. Exact service bytes restored by SHA-256; recipe/dyd1029-red.py and red-bytes receipt retain the operation.',
    'casing-red: 1 failed / 1 passed; ignored-casing-red: 2 failed / 0 passed. Linux .GIT was omitted by unconditional case-insensitive administrative-name checks. Both ignored and untracked cases were refused by independent status reconstruction before deletion; these runs do not prove data loss. Fixed capture/manifest validation to use native platform comparison. Windows branch aliases now require exact canonical spelling; distinct Linux refs remain valid. Native Windows proof remains owed.',
    'Casing RED replay: temporarily change only the two .git-name comparisons in SafeDeleteFiles.SkipGit and Validate from SafeDeletePaths.Comparison to StringComparison.OrdinalIgnoreCase; run AdministrativeNameCasing_PreservesDistinctFilesOrRefusesAliases under the capped wrapper; expect both Linux theory rows to fail with Reconstructed file/index/status snapshot differs. Restore exact candidate bytes and rerun SafeDelete. Receipt hashes bind the original red and successor sources.',
    'focused-09: 131 passed, zero skips; later successor-witness-02: 212 passed, zero skips, including strengthened remote/reflog gc, partial-stage, lease/CAS and all three whole-suite .NET counterexamples.',
    'light-03: 4068 passed, zero failures, 17 platform skips. Final whole .NET coverage suite is reused for the latest own/reached Light verdict, per testing-strategy; skipped native tests do not establish platform proof.',
    'selection-witness: 31 Python tests passed. dependency-witness: 14 passed after locked viewer/statechart restoration. python-driver-02: 22 passed.',
    'First coverage run: .NET 7143 passed, 3 failed, 54 skipped; all failures were our missing smoke/doc/CI registration, subsequently fixed. Python 1220 tests: 2 failures, 1 error, 58 skips; our platform selection expectation and missing locked viewer/statechart dependencies were corrected. No unrelated baseline code was repaired.',
    'dotnet-coverage-final: the complete suite passed; the only policy finding was SafeDeleteHistory.Capture HCRAP 20.341333333333335 above 20. Per-worktree reference capture was separated and a source-gc/recovery-ref regression added. The subsequent .NET receipts carry the successor verdict.',
    'Diagnostic-own/model coverage probes inspected the first failed run only. Their locally printed hcrap labels used a standard CRAP approximation and are not canonical HCRAP policy findings. Only the facade reports use the actual gate formula/cognitive metrics and native-platform denominator.',
    '', 'Reproducible Linux recipe',
    'Extract raw-evidence.tar.gz to a fresh directory. recipe/dyd1029-run.py is the exact capped wrapper used; copy it to /tmp/dyd1029-run.py and choose fresh labels (it refuses label overwrite). Run from the candidate worktree. It discovers the nearest user-manager slice from /proc/self/cgroup.',
    'The existing /var/tmp/dydo-gate-lock.sh remains outside systemd-run. .NET env: MSBUILDDISABLENODEREUSE=1 DOTNET_CLI_USE_MSBUILD_SERVER=0 UseSharedCompilation=false. Gate cap: MemoryMax=8G, MemorySwapMax=0, OOMPolicy=continue, timeout 3600. Probe cap: 4G, timeout 120. Sandbox bus refusal requires escalation of the capped command, never an uncapped retry.',
    'python3 /tmp/dyd1029-run.py REPLAY-feature gate dotnet test DynaDocs.Tests/DynaDocs.Tests.csproj --filter FullyQualifiedName~SafeDelete --logger trx',
    "python3 /tmp/dyd1029-run.py REPLAY-light gate dotnet test DynaDocs.Tests/DynaDocs.Tests.csproj --filter 'FullyQualifiedName~SafeDelete|FullyQualifiedName~Clean|FullyQualifiedName~Git|FullyQualifiedName~Guard|FullyQualifiedName~BashCommandAnalyzer|FullyQualifiedName~DangerousPattern|FullyQualifiedName~InitCommandTests|FullyQualifiedName~Completion|FullyQualifiedName~Help|FullyQualifiedName~CommandSmoke|FullyQualifiedName~CommandDocConsistency|FullyQualifiedName~ReleaseWorkflow' --logger trx",
    'python3 /tmp/dyd1029-run.py REPLAY-static gate .static-gates/python/bin/python DynaDocs.Tests/coverage/gap_check.py gate static --stack dotnet,python',
    'python3 /tmp/dyd1029-run.py REPLAY-dotnet gate .static-gates/python/bin/python DynaDocs.Tests/coverage/gap_check.py gate coverage --stack dotnet',
    'python3 /tmp/dyd1029-run.py REPLAY-python gate .static-gates/python/bin/python DynaDocs.Tests/coverage/gap_check.py gate coverage --stack python',
    'python3 /tmp/dyd1029-run.py REPLAY-mutation gate .static-gates/python/bin/python DynaDocs.Tests/coverage/gap_check.py gate mutation --since dee4861ae2691e41d9e60985e3e0ffb0c7ea987d --stack dotnet',
    'Locked prerequisites: CPython 3.14 assurance venv from requirements.lock; dotnet tool restore from .config/dotnet-tools.json; pnpm --frozen-lockfile in DynaDocs.Tests/coverage, viewer and skills/engineering/statechart/scripts. The receipts retain observed tools and commands. SDK 10.0.303 / runtime 10.0.14.',
    'Dormant repeated guard performance proofs were not triggered: no fundamental command reader/architecture change or suspected performance regression; existing reader predicates were reused. Ordinary coverage witnesses execute in the full suite.',
    '', 'Native Windows route and limits',
    'No Windows execution was observed by this writer. The new safe-delete-windows CI job pins candidate bytes/runtime, enables link-refusal fixtures, discovers the actual SafeDelete selection, runs it through the memory-capped facade and requires nonzero results, every test passed, no skips and cap receipts. Captain must execute this job on the actual candidate/merge ref and retain artifacts.',
    'Equivalent native command: python DynaDocs.Tests/coverage/gap_check.py test --stack dotnet -- --filter FullyQualifiedName~SafeDelete --logger trx. Use the existing Windows shared suite slot; facade must report its enforced Job Object memory cap.',
    'verify-dydo remains Windows-only. Its documented launch/doctor/drive --journey archive/cleanup route now executes real local CLI deletion, source gc and restore; follow skills/engineering/verify-dydo/SKILL.md for the native slot wrapper and retained evidence. No Linux driver execution is claimed.',
    'macOS/unsupported busy probes refuse worktree removal; unsupported worktree metadata restoration also refuses. Branch archive remains available. Windows reparse points/unsupported metadata refuse; Linux unsupported ownership, xattrs, hard links and special files refuse. Busy probes and final rechecks leave a small race with arbitrary external writers, not an atomic filesystem snapshot.',
    '', 'T3_RELEASE_UNPROVEN: target retained',
    'Production recognizes default, configured, previous and /.t3/worktrees/ roots, including T3CODE_HOME userdata settings; unreadable authoritative settings refuse. No supported/verifiable release route combining all sharing threads (including children/archived ownership), settled/activeRun state, provider sessions, terminals and a workspace lease is established.',
    'Exposed worktree tools are list/status/handoff; handoff is create-only. CLI list omits subagents. Bundled internal StorageCleanup owns an activity check/lease route, but it is not an established public deletion API. No database writes, invented API calls or unauthorized settling were performed.',
    'Captain native recipe: dispatch only its commissioned disposable T3 proof child with isolation:worktree at the candidate; record canonical tree, branch, all owning thread identities and initial list/read health. From an owned outside caller, archive worktree TARGET must refuse while active and leave refs/files intact. Without an authoritative supported release/lease route it must also retain an inactive target. Record this refusal as a finding, not native deletion success. Do not enable the production route until a later implementation and disposable-host proof establish every required owner/session/terminal check, safe removal and subsequent list/read/no-crash health. Never count automatic later worktree recreation as archive restoration.',
    'Gherkin injection proves active/unavailable/unproven-settled refusal and eligibility only for a fake explicitly proof-enabled settled route. It makes no host-health claim. t3-source-evidence.txt and t3-settings-evidence.txt retain exact source digests and numbered excerpts; the owner commission explicitly permits shipping the remaining command while retaining T3 targets.',
    '', 'Assurance gaps',
    'Mutation: unavailable (Pending DYD-103), exit 2, not a pass. Captain/review stage owns final mutation assurance and independent full-strength Claude + Codex reviews.',
    'Native Windows execution/coverage union and native T3 lifecycle proof are not established here. No platform skip is counted as proof.',
    '', 'Exact raw runs (full argv/environment/source identity/logs are in raw-evidence.tar.gz)',
]
for receipt,label in receipts:
    lines.append(f"{label}: exit={receipt.get('exit','RUNNING')} start={receipt['start']} end={receipt.get('end','pending')}; raw/dyd1029-runs/{label}/receipt.json and raw.log")
    lines.append('  argv='+json.dumps(receipt['argv']))
python_receipt = json.loads((runs/'python-coverage-final/receipt.json').read_text())
python_paths = [name for name in python_receipt['files'] if name.endswith('.py') or name in (
    'DynaDocs.Tests/coverage/dotnet-platforms.json', 'DynaDocs.Tests/coverage/test-associations.json',
    'DynaDocs.Tests/coverage/requirements.lock', 'DynaDocs.Tests/coverage/pyproject.toml')]
changed_python = [name for name in python_paths if hashlib.sha256(Path(name).read_bytes()).hexdigest() != python_receipt['files'][name]]
if changed_python: raise SystemExit('Python source changed after passing coverage: '+repr(changed_python))
lines.append(f'Python source/config equality after final .NET-only history/casing changes: all {len(python_paths)} measured Python and applicable configuration files retain identical SHA-256 bytes; Python coverage/static remain applicable.')
for label in ('static-final','casing-green','dotnet-static-after-casing','dotnet-coverage-after-casing','python-coverage-final','mutation-final'):
    receipt = json.loads((runs/label/'receipt.json').read_text())
    lines.append(f"FINAL {label}: exit={receipt.get('exit','RUNNING')}; see complete raw verdict and platform findings.")
(evidence/'proof.txt').write_text('\n'.join(lines)+'\n')
print(evidence/'proof.txt')
