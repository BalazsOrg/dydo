from pathlib import Path
import hashlib
import json
import sys

source = Path('Services/SafeDeleteService.cs')
backup = Path('/tmp/dyd1029-service-before-red.cs')
if sys.argv[1] == 'remove':
    original = source.read_bytes()
    backup.write_bytes(original)
    source.write_text('''namespace DynaDocs.Services;
internal sealed class SafeDeleteService
{
    internal SafeDeleteService(string directory, SafeDeleteDependencies dependencies, TextWriter output)
    {
        _ = directory; _ = dependencies; _ = output;
    }
    internal int Archive(string kind, string target, string? remote, bool dryRun)
    { _ = kind; _ = target; _ = remote; _ = dryRun; return 2; }
    internal int List() => 2;
    internal int Restore(string id, string? branch, string? path, bool remote)
    { _ = id; _ = branch; _ = path; _ = remote; return 2; }
}
''')
    Path('/tmp/dyd1029-red-bytes.json').write_text(json.dumps({
        'original': hashlib.sha256(original).hexdigest(),
        'removed': hashlib.sha256(source.read_bytes()).hexdigest(),
        'meaning': 'Archive implementation removed; retained tests invoke unchanged command boundary.'
    }, indent=2)+'\n')
else:
    original = backup.read_bytes()
    source.write_bytes(original)
    expected = json.loads(Path('/tmp/dyd1029-red-bytes.json').read_text())['original']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    print('Exact implementation bytes restored:', expected)
