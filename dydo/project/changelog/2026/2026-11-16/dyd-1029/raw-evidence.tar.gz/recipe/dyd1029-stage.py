from pathlib import Path
import subprocess

base = 'dee4861ae2691e41d9e60985e3e0ffb0c7ea987d'
expected = set('''.codex/rules/dydo.rules
.github/workflows/ci.yml
Commands/ArchiveCommand.cs
Commands/GuardCommand.cs
Commands/HelpCommand.cs
Commands/InitCommand.cs
DynaDocs.Tests/Commands/CommandSmokeTests.cs
DynaDocs.Tests/Features/safe-delete.feature
DynaDocs.Tests/Integration/GuardWorktreeRemovalTests.cs
DynaDocs.Tests/Integration/SafeDeleteBoundaryTests.cs
DynaDocs.Tests/Integration/SafeDeleteFakeT3Policy.cs
DynaDocs.Tests/Integration/SafeDeleteGuardTests.cs
DynaDocs.Tests/Integration/SafeDeletePolicyTests.cs
DynaDocs.Tests/Integration/SafeDeleteTests.cs
DynaDocs.Tests/Services/BashCommandAnalyzerTests.cs
DynaDocs.Tests/Steps/SafeDeleteSteps.cs
DynaDocs.Tests/Workflow/ReleaseWorkflowTests.cs
DynaDocs.Tests/coverage/dotnet-platforms.json
DynaDocs.Tests/coverage/test-associations.json
DynaDocs.Tests/coverage/tests/test_control_dydo.py
DynaDocs.Tests/coverage/tests/test_dotnet_platform.py
Models/ArchiveConfig.cs
Models/DydoConfig.cs
Models/SafeDeleteFile.cs
Models/SafeDeleteManifest.cs
Models/SafeDeleteTip.cs
Program.cs
Scaffold/dydo/reference/dydo-commands.md
Serialization/DydoJsonContext.cs
Serialization/SafeDeleteJsonContext.cs
Services/BashCommandAnalyzer.cs
Services/CompletionProvider.cs
Services/ISafeDeleteT3Policy.cs
Services/SafeDeleteDependencies.cs
Services/SafeDeleteFiles.cs
Services/SafeDeleteGit.cs
Services/SafeDeleteGitHub.cs
Services/SafeDeleteHistory.cs
Services/SafeDeletePaths.cs
Services/SafeDeleteRepository.cs
Services/SafeDeleteService.cs
Services/SafeDeleteStore.cs
Services/SafeDeleteT3Policy.cs
Services/SafeDeleteWindowsMetadata.cs
dydo/reference/configuration.md
dydo/reference/dydo-commands.md
dydo/understand/guard-system.md
skills/engineering/verify-dydo/SKILL.md
skills/engineering/verify-dydo/resources/features/README.md
skills/engineering/verify-dydo/resources/features/archive.md
skills/engineering/verify-dydo/scripts/control_dydo.py'''.splitlines())
prefix = 'dydo/project/changelog/2026/2026-11-16/dyd-1029/'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip() == 'DYD-1029-safe-delete'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == base
subprocess.run(['git','merge-base','--is-ancestor',base,'HEAD'],check=True)

def names(*arguments):
    return {name.decode() for name in subprocess.check_output(['git',*arguments,'-z']).split(b'\0') if name}

changed = names('diff','--name-only','HEAD') | names('ls-files','--others','--exclude-standard')
unexpected = sorted(path for path in changed if path not in expected and not path.startswith(prefix))
if unexpected: raise SystemExit('OWNERSHIP COLLISION: '+repr(unexpected))
owned_list = Path(prefix)/'owned-paths.txt'
changed.add(str(owned_list))
owned_list.write_text('\n'.join(sorted(changed))+'\n')
subprocess.run(['git','add','--',*sorted(changed)],check=True)
print('Staged',len(changed),'explicit owned paths')
