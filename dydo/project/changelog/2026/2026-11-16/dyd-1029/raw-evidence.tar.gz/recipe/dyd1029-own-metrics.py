from pathlib import Path
import xml.etree.ElementTree as ET
import sys

root = ET.parse(sys.argv[1]).getroot()
for module in root.findall('.//Module'):
    files = {item.attrib['uid']:item.attrib['fullPath'] for item in module.findall('./Files/File')}
    for method in module.findall('.//Method'):
        file = method.find('FileRef')
        path = files.get(file.attrib['uid'],'') if file is not None else ''
        if '/Services/SafeDelete' not in path and '/Commands/ArchiveCommand' not in path and '/Models/SafeDelete' not in path: continue
        points = method.findall('./SequencePoints/SequencePoint')
        branches = method.findall('./BranchPoints/BranchPoint')
        line = sum(int(p.attrib['vc'])>0 for p in points)/max(1,len(points))
        branch = sum(int(p.attrib['vc'])>0 for p in branches)/max(1,len(branches))
        cc = int(method.attrib.get('cyclomaticComplexity',1))
        hcrap = cc*cc*(1-line)**3+cc
        if line < .8 or branches and branch < .6 or hcrap>20:
            print(Path(path).name, method.findtext('Name'),f'points={line:.1%}, branch={branch:.1%}, cc={cc}, hcrap={hcrap:.2f}')
