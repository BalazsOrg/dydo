from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path.cwd()
evidence = root / 'dydo/project/changelog/2026/2026-11-16/dyd-1029'
evidence.mkdir(parents=True, exist_ok=True)
final_receipt = json.loads(Path('/tmp/dyd1029-runs/dotnet-coverage-after-casing/receipt.json').read_text())
if final_receipt.get('exit') != 0:
    raise SystemExit('Final .NET coverage has not passed')
current_names = {name.decode() for name in subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z']).split(b'\0') if name}
prefix = str(evidence.relative_to(root)) + '/'
measured_names = {name for name in final_receipt['files'] if not name.startswith(prefix)}
current_sources = {name for name in current_names if not name.startswith(prefix) and Path(name).is_file()}
if measured_names != current_sources:
    raise SystemExit('Source set changed since final coverage: '+repr(measured_names ^ current_sources))
for name in measured_names:
    with Path(name).open('rb') as source:
        if hashlib.file_digest(source,'sha256').hexdigest() != final_receipt['files'][name]:
            raise SystemExit('Source changed since final coverage: '+name)
suffixes = {'.json','.xml','.trx','.log','.stdout','.stderr','.sarif','.txt','.py'}
paths = []
for directory in (Path('/tmp/dyd1029-runs'), root / 'DynaDocs.Tests/coverage/results', Path('/tmp/dyd1029-static-01-results'), Path('/tmp/dyd1029-coverage-01-results'), Path('/tmp/dyd1029-before-history-fix-results')):
    if directory.exists():
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix in suffixes:
                paths.append((path, 'raw/' + str(path.relative_to(root) if path.is_relative_to(root) else path.relative_to('/tmp'))))
for directory in sorted(Path('/tmp').glob('dyd1029-*')):
    if directory.is_dir() and directory.name != 'dyd1029-runs' and not directory.name.endswith('results'):
        for path in directory.rglob('*.trx'):
            paths.append((path,'raw/'+str(path.relative_to('/tmp'))))
for name in ('dyd1029-run.py','dyd1029-red.py','dyd1029-red-bytes.json','dyd1029-service-before-red.cs','dyd1029-own-metrics.py','dyd1029-report.py','dyd1029-static-metrics.py','dyd1029-proof.py','dyd1029-evidence.py','dyd1029-stage.py'):
    path = Path('/tmp')/name
    if path.exists(): paths.append((path,'recipe/'+name))
archive = evidence/'raw-evidence.tar.gz'
digests = {}
first = {}
with tarfile.open(archive,'w:gz') as output:
    for path, name in paths:
        with path.open('rb') as source:
            digest = hashlib.file_digest(source,'sha256').hexdigest()
        digests[name] = digest
        if digest not in first:
            output.add(path,arcname=name,recursive=False)
            first[digest] = name
        else:
            info = output.gettarinfo(path,arcname=name)
            info.type = tarfile.LNKTYPE
            info.linkname = first[digest]
            info.size = 0
            output.addfile(info)
(evidence/'raw-evidence-index.json').write_text(json.dumps({
    'archiveSha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),
    'files':digests
},indent=2)+'\n')
names = subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z']).split(b'\0')
sources = {}
for raw in names:
    if not raw: continue
    path = Path(raw.decode())
    if path.is_file() and not path.is_relative_to(evidence.relative_to(root)):
        sources[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
(evidence/'final-source-bytes.json').write_text(json.dumps({
    'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'files':sources
},indent=2)+'\n')
print(archive,archive.stat().st_size,'bytes;',len(paths),'raw files')
