from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

root = Path('/tmp/dyd1133-runs')
evidence = Path('dydo/project/changelog/2026/2026-11-17/dyd-1133')
production = ['Models/SafeDeleteManifest.cs','Services/SafeDeleteFiles.cs','Services/SafeDeleteService.cs','Services/SafeDeleteStore.cs']
tests = ['DynaDocs.Tests/Integration/SafeDeleteInputsTests.cs','DynaDocs.Tests/Features/safe-delete.feature','DynaDocs.Tests/Steps/SafeDeleteSteps.cs']
paths = production + tests
digest = lambda data: hashlib.sha256(data).hexdigest()
runs = {}
for directory in sorted(root.iterdir()):
    receipt_path = directory / 'receipt.json'
    if not receipt_path.exists() or directory.name.startswith('evidence-'):
        continue
    receipt = json.loads(receipt_path.read_text())
    row = {key: receipt.get(key) for key in ('start','end','head','status','argv','exit')}
    row['files'] = {path: receipt['files'].get(path) for path in paths}
    row['raw_log'] = str(directory / 'raw.log')
    row['trx'] = []
    for trx in directory.rglob('*.trx'):
        tree = ET.parse(trx)
        ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
        counter = tree.find('.//t:Counters',ns)
        results = tree.findall('.//t:UnitTestResult',ns)
        row['trx'].append({'path':str(trx),'counters':counter.attrib,'results':[{k:r.attrib.get(k) for k in ('testName','outcome')} for r in results]})
    runs[directory.name] = row
    if directory.name.startswith('discovery'):
        log = (directory/'raw.log').read_text()
        row['discovered_count'] = sum(line.startswith('    ') for line in log.splitlines())
        row['input_scenario_discovered'] = 'Recover files governed by repository-local exclude and attributes' in log

original = {path:digest(subprocess.check_output(['git','show','74bf3bc332de5aaedd5523e506fbf6621788a6bb:'+path])) for path in production}
current = {path:digest(Path(path).read_bytes()) for path in paths}
assert all(runs['red-production-reversed']['files'][path] == original[path] for path in production)
assert runs['red-before-fix']['exit'] == 1 and runs['red-production-reversed']['exit'] == 1
assert all(runs[label]['exit'] == 0 for label in ('prerequisites','discovery-expanded','discovery-restored','green-initial','green-expanded','light-final','native-linux','static-final'))
assert all(runs[label]['files'][path] == current[path] for label in ('discovery-restored','light-final','native-linux','static-final') for path in paths)
assert all(runs['red-production-reversed']['files'][path] == current[path] for path in tests)
adapter = Path('DynaDocs.Tests/coverage/results/adapters/dotnet-static.json')
static = json.loads(adapter.read_text())
collectors = {name:{'state':row.get('state'),'errors':row.get('errors'),'findings':row.get('findings')} for name,row in static['collectors'].items()}
assert len(collectors) == 7
assert all(not row['errors'] and not row['findings'] for row in collectors.values())
print('Static collectors:',json.dumps(collectors))
summary = {'base':'74bf3bc332de5aaedd5523e506fbf6621788a6bb','runs':runs,'production_base_hashes':original,'final_source_hashes':current,
           'production_only_reversal_matches_base':True,'retained_tests_match_final_reversal':True,'final_source_bytes_match_discovery_light_native_static':True,
           'static_adapter':{'candidate':static['candidate'],'collectors':collectors,'sha256':digest(adapter.read_bytes())},'runner_sha256':digest(Path('/tmp/dyd1133-run.py').read_bytes()),'native_recipe_sha256':digest(Path('/tmp/dyd1133-native.py').read_bytes())}
(evidence/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,row in runs.items():
    print(name,'exit',row['exit'],'discovered',row.get('discovered_count'),'counters',[trx['counters'] for trx in row['trx']])
print('Production-only reversal equals pinned base; retained tests unchanged; all final runtime bytes equal discovery/Light/native/static receipts.')
