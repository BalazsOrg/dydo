from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone

label, level, *command = sys.argv[1:]
run = Path('/tmp/dyd1133-runs') / label
run.mkdir(parents=True, exist_ok=False)
files = subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z']).split(b'\0')
hashes = {}
for raw in files:
    if not raw:
        continue
    name = os.fsdecode(raw)
    path = Path(name)
    if path.is_file():
        hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
slice_name = next(part for part in reversed(Path('/proc/self/cgroup').read_text().strip().split('/')) if part.endswith('.slice'))
argv = ['/var/tmp/dydo-gate-lock.sh','env','MSBUILDDISABLENODEREUSE=1','DOTNET_CLI_USE_MSBUILD_SERVER=0','UseSharedCompilation=false',
        'systemd-run','--user','--scope',f'--slice={slice_name}','-p',f'MemoryMax={"4G" if level == "probe" else "8G"}',
        '-p','MemorySwapMax=0','-p','OOMPolicy=continue','timeout','120' if level == 'probe' else '3600',*command]
receipt = {'start':datetime.now(timezone.utc).isoformat(),'cwd':str(Path.cwd()),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
           'status':subprocess.check_output(['git','status','--porcelain'],text=True),'files':hashes,'argv':argv}
(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(str(run),flush=True)
with (run/'raw.log').open('w') as log:
    result = subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,check=False)
receipt.update(exit=result.returncode,end=datetime.now(timezone.utc).isoformat())
(run/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print((run/'raw.log').read_text()[-6000:])
raise SystemExit(result.returncode)
